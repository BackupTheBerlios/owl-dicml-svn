import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

/**
IndexDicml holds the dialog and routines for indexing a dicML-File
*/
class IndexDicml extends JDialog implements ActionListener 
{
  JLabel lInfo;
  JProgressBar pbStatus;
  JButton btOk, btAbort;
  
  private File dicmlFile;
  
  private IndexDicmlWork workerThread;
  
  IndexDicml(String pathToFile, Frame owner, boolean modal)
  {
    super(owner, modal);
    
    GridBagLayout gbl = new GridBagLayout();
    GridBagConstraints gbc;
    setLayout(gbl);
    
    gbc = new GridBagConstraints();
    lInfo = new JLabel();
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets(1, 1, 1, 1);
    gbl.setConstraints(lInfo, gbc);
    add(lInfo);
    
    dicmlFile = new File(pathToFile);
    lInfo.setText("Die Datei\"" + dicmlFile.getName() + "\" wird indexiert...");
    
    gbc = new GridBagConstraints();
    pbStatus = new JProgressBar(JProgressBar.HORIZONTAL, 0, 100);
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.gridwidth = 2;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets(1, 1, 1, 1);
    gbl.setConstraints(pbStatus, gbc);
    pbStatus.setStringPainted(true);
    pbStatus.setString("0%");
    pbStatus.setValue(0);
    add(pbStatus);

    gbc = new GridBagConstraints();
    btOk = new JButton("Ok");
    gbc.gridx = 0;
    gbc.gridy = 2;
    gbc.gridwidth = 1;
    gbc.anchor = GridBagConstraints.WEST;
    gbc.fill = GridBagConstraints.NONE;
    gbc.insets = new Insets(1, 1, 1, 1);
    gbl.setConstraints(btOk, gbc);
    btOk.setEnabled(false);
    btOk.addActionListener(this);
    btOk.setActionCommand("ok");
    add(btOk);

    gbc = new GridBagConstraints();
    btAbort = new JButton("Abbrechen");
    gbc.gridx = 1;
    gbc.gridy = 2;
    gbc.gridwidth = 1;
    gbc.anchor = GridBagConstraints.EAST;
    gbc.fill = GridBagConstraints.NONE;
    gbc.insets = new Insets(1, 1, 1, 1);
    btAbort.setEnabled(true);
    btAbort.addActionListener(this);
    btAbort.setActionCommand("abort");
    gbl.setConstraints(btAbort, gbc);
    add(btAbort);
 
    pack();
    
    
//    setSize(300, 150);
    setTitle("Indexiervorgang");
    this.setLocation(100, 100);
    
    //start new worker-thread
 
    workerThread = new IndexDicmlWork(dicmlFile, this);
    workerThread.start();
    
    setVisible(true);
  }
  
  public void actionPerformed(ActionEvent e)
  {
    if(e.getActionCommand().equals("ok"))
    {
      setVisible(false);
      dispose();
    }
    else if(e.getActionCommand().equals("abort"))
    {
      workerThread.abort = true;
    }
}
    
  
  public void setStatusBarValue(int alreadyDone)
  {
     if(alreadyDone > 100)
    {
      btAbort.setEnabled(false);
      btOk.setEnabled(true);
      lInfo.setText("Indexiervorgang abgeschlossen");
      pbStatus.setValue(alreadyDone);
      pbStatus.setString("100%");
    }
    else
    {
      pbStatus.setValue(alreadyDone);
      pbStatus.setString(new String().valueOf(alreadyDone) + "%");
    }
  }
  
  
  protected void finalize()
  {
   // dicmlFile.finalize();
  }
}
