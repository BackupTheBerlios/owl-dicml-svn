import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import javax.xml.transform.*;
import java.net.*;
import java.io.*;

class DicmlRead extends JPanel
{
  private JEditorPane dicmlView;
  private Transformer transformer;
  private TransformerFactory tFactory;
  private File emptyFile;

  DicmlRead()
  {
    setLayout(new GridLayout());
    dicmlView = new JEditorPane();
    dicmlView.setVisible(true);
    dicmlView.setEditable(false);
    dicmlView.setContentType("text/html"); 
    setBackground(new Color(255, 0, 0));
    
    JScrollPane scrollPane = new JScrollPane(dicmlView);
    add(scrollPane);
    
    emptyFile = new File(".." + File.separator + "res" + File.separator + "empty.html");
    //init XSLT
    try
    {
      dicmlView.setPage(emptyFile.toURL());
    tFactory = TransformerFactory.newInstance();

    transformer =
      tFactory.newTransformer
         (new javax.xml.transform.stream.StreamSource
            (".." + File.separator + "etc" + File.separator + "style.xsl"));
    }
    catch (Exception e)
    {
 //     e.printStackTrace( );
      JOptionPane.showMessageDialog(this,  "Fehler beim XSLT-Transformationsvorgang:\n" + e.getMessage(), "FEHLER", JOptionPane.ERROR_MESSAGE);
    
    }
}
  
  public void parse(String text)
  {
    try
    {
      
    transformer.transform
      (new javax.xml.transform.stream.StreamSource(new StringReader(text)),
       new javax.xml.transform.stream.StreamResult
            (new FileOutputStream(".." + File.separator + "etc" + File.separator +  "entry.html"))); 
            
      File resultFile = new File(".." + File.separator + "etc" + File.separator + "entry.html");
      dicmlView.setPage(emptyFile.toURL());
      dicmlView.setPage(resultFile.toURL());
    }
    catch (Exception e)
    {
      JOptionPane.showMessageDialog(this,  "Fehler beim Aufrufen des Eintrags:\n" + e.getMessage(), "FEHLER", JOptionPane.ERROR_MESSAGE);
    
    }
    
    /*
    //test XSLT
    try {
    TransformerFactory tFactory = TransformerFactory.newInstance();

    Transformer transformer =
      tFactory.newTransformer
         (new javax.xml.transform.stream.StreamSource
            ("style.xsl"));

    transformer.transform
      (new javax.xml.transform.stream.StreamSource
            ("en-de_head.xml"),
       new javax.xml.transform.stream.StreamResult
            ( new FileOutputStream("test.html"))); 
   
    }
    catch (Exception e) {
 //     e.printStackTrace( );
      JOptionPane.showMessageDialog(this,  "Fehler beim XSLT-Transformationsvorgang:\n" + e.getMessage(), "FEHLER", JOptionPane.ERROR_MESSAGE);
    
    }
    */
    /*
    try
    {
      File pageFile = new File("test.html");
//      dicmlView.setText(pageFile.toURI().toString());
      dicmlView.setPage(pageFile.toURI().toString());
    }
    catch (Exception e)
    {
    JOptionPane.showMessageDialog(this,  "Fehler beim Aufrufen des Eintrags:\n" + e.getMessage(), "FEHLER", JOptionPane.ERROR_MESSAGE);
    
    }
    */
  }

}
