import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.*;
import java.io.*;
import javax.xml.transform.*;
import java.net.*;
/**
OwlReader holds the main-window of the owl-reader
*/
class OwlReader extends JFrame implements ActionListener, ListSelectionListener, DocumentListener
{
	private JList listView;
	private JTextField tSearch;                  
	private DicmlRead tDicml;
  private JMenuBar mainMenuBar;
  
  private String lemmaName[];
  private long lemmaBegin[], lemmaEnd[];
  
  private RandomAccessFile dicmlAccess;
  //constructor
	OwlReader()
	{
    //init WindowManager
    GridBagLayout layout = new GridBagLayout();
    setLayout(layout);
    
    //init listView
    GridBagConstraints constraint = new GridBagConstraints();
    String[] LISTDATA = {""};
    listView = new JList(LISTDATA);
    constraint.gridx = 0;
    constraint.gridy = 1;
    constraint.gridwidth = 1;
    constraint.gridheight = 1;
    constraint.ipadx = 120;
    constraint.weightx = 10;
    constraint.weighty = 100;
    constraint.fill = GridBagConstraints.BOTH;
    constraint.anchor = GridBagConstraints.NORTHEAST;
    listView.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    listView.addListSelectionListener(this);
    JScrollPane scrollPane = new JScrollPane(listView);
    layout.setConstraints(scrollPane, constraint);
    add(scrollPane);
    
    //init tSearch
    constraint = new GridBagConstraints();
    tSearch = new JTextField("");
    constraint.gridx = 0;
    constraint.gridy = 0;
    constraint.gridwidth = 1;
    constraint.gridheight = 1;
    constraint.weightx = 10;
    constraint.weighty = 0;
    constraint.ipadx = 100;
    constraint.insets = new Insets(0, 0, 10, 0);
    constraint.fill = GridBagConstraints.BOTH;
    constraint.anchor = GridBagConstraints.NORTHEAST;
    layout.setConstraints(tSearch, constraint);
    tSearch.getDocument().addDocumentListener(this);
    add(tSearch);
    
    //init tDicml
    constraint = new GridBagConstraints();
    tDicml = new DicmlRead();
    constraint.gridx = 1;
    constraint.gridy = 0;
    constraint.gridwidth = 1;
    constraint.gridheight = 2;
    constraint.weightx = 100;
    constraint.weighty = 100;
    constraint.fill = GridBagConstraints.BOTH;
    constraint.anchor = GridBagConstraints.NORTHEAST;
    constraint.insets = new Insets(0, 10, 0, 0);
    layout.setConstraints(tDicml, constraint);
    add(tDicml);
    //finalize
    pack();
    
    //init menubar
    mainMenuBar = new JMenuBar();
    mainMenuBar.add(createMainMenu());
    
		//init window
    setJMenuBar(mainMenuBar);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("owl-reader vers 0.08");
		setSize(600, 400);
		setVisible(true);
    
	}
  
  private JMenu createMainMenu()
  {
    JMenu menu = new JMenu("Men\u00FC");
    JMenuItem mi;
    
    //open dictionary
    mi = new JMenuItem("W\u00F6rterbuch \u00F6ffnen", 'f');
    mi.addActionListener(this);
    mi.setActionCommand("opendic");
    menu.add(mi);
    
    //infos
    mi = new JMenuItem("Infos", 'i');
    mi.addActionListener(this);
    mi.setActionCommand("info");
    menu.add(mi);
    
    //quit
    mi = new JMenuItem("Beenden", 'e');
    mi.addActionListener(this);
    mi.setActionCommand("quit");
    menu.add(mi);
   return menu;
  }

  private void openDictionary()
  {
    File fileDicml;
    String pathId;
    File fileId;
    IndexDicml indexDialog;
    
    //show file-selector
    
    //TODO: add copyright notice to documentation (IMPORTANT!!!)
    ExampleFileFilter filter = new ExampleFileFilter();
    filter.addExtension("dicml");
    filter.setDescription("dicml-W\u00F6rterbuchdatei");
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setFileFilter(filter);
   
    if(fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION )
    {
      fileDicml = fileChooser.getSelectedFile();
      pathId = fileDicml.getAbsolutePath() + ".id";
      fileId = new File(pathId);
      if(fileId.exists())
      {
        openDicFile(fileDicml);
      }
      else
      {
        //ask the user
        if(JOptionPane.showConfirmDialog(this, "Die Datei '" + fileDicml.getName() + "' muss vor der ersten Benutzung indexiert werden.\n\nSoll diese Indexierung nun ausgef\u00FChrt werde?\n(kann ein bissschen dauern)", "owl-reader", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
        {
          //show indexing dialog
          indexDialog = new IndexDicml(fileDicml.getAbsolutePath() ,this, true);
        
          openDicFile(fileDicml);
        }
      }
    }
  }
  
  public void openDicFile(File f)
  {
    LineNumberReader idReader;
    String line;
    int lineCount=0;
    int entryCount=0;
    
    try
    {
      if(dicmlAccess != null)
      {
        //close old dicml-file
        dicmlAccess.close();
      }
      //open dicml-file for accessing
      dicmlAccess = new RandomAccessFile(f, "r");
      
      //read in the list of entries
      idReader = new LineNumberReader(new FileReader(f.getAbsolutePath() + ".id"));
      
      //count the lines
      while(idReader.readLine() != null)
      {
        lineCount++;
      }
      
      idReader.close();
      idReader = new LineNumberReader(new FileReader(f.getAbsolutePath() + ".id"));
      
      //init arrays
      entryCount = lineCount / 3;
      lemmaName = new String[entryCount];
      lemmaBegin = new long[entryCount];
      lemmaEnd = new long[entryCount];
      
      for(int i = 0; i < entryCount; i++)
      {
        //add entry to array
        line = idReader.readLine();
        lemmaName[i] = line;
        line = idReader.readLine();
        lemmaBegin[i] = Integer.parseInt(line);
        line = idReader.readLine();
        lemmaEnd[i] = Integer.parseInt(line);
        
      }
      
      //update list
      listView.setListData(lemmaName);
      
      idReader.close();
    }
    catch(Exception e)
    {
      if(e.getMessage().equals("-1"))
      {
        //some kind of selection error, just ignore it
      }
      else
      {
        JOptionPane.showMessageDialog(this,  "Fehler beim Einlesen des W\u00F6rterbuchs:\n" + e.getMessage(), "FEHLER", JOptionPane.ERROR_MESSAGE);
      }
    }
  }
  
  /**
  react to various action-based events
  */  
  public void actionPerformed(ActionEvent event)
  {
    String cmd = event.getActionCommand();
    if(cmd.equals("opendic"))
    {
      openDictionary();
    }
    else if(cmd.equals("info"))
    {
      //show info dialog
      
      JOptionPane.showMessageDialog(this, "owl-reader\n\nVersion 0.08\n\nDieses Programm ist (noch) nicht f\u00FCr den \u00F6ffentlichen Gebrauch gedacht!\nES WIRD KEINE HAFTUNG \u00DCBERNOMMEN!\n\n(c) 2004 Thomas Krause und Julius Becker, alle Rechte vorbehalten.", "Infos zu owl-reader",JOptionPane.INFORMATION_MESSAGE);
    }
    else if(cmd.equals("quit"))
    {
      //quit
      System.exit(0);
    }
  }
  
  /**
  reacts on changings in the search-textfield
  */
  public void changedUpdate(DocumentEvent event)
  {
    
    char charTextField = '\u0000';
    char charEntryList = '\u0000';
    String enteredText = tSearch.getText().toLowerCase();
    int entryToSelect = 0;
    boolean compare = false;
    //for every character in enteredText
    for(int i=0; i < enteredText.length(); i++)
    {
      charTextField = enteredText.charAt(i);
      //compare the i-th character of the entered text with the i-th one of the entry of the list 
      do
      {
        if(entryToSelect < lemmaName.length)
        {
          int lemmaLength = lemmaName[entryToSelect].length();
          if(i < lemmaLength)
          {
            charEntryList = lemmaName[entryToSelect].toLowerCase().charAt(i);
          }
          else
          {
            charEntryList = lemmaName[entryToSelect].toLowerCase().charAt(lemmaLength-1);
          }
          compare = (charTextField == charEntryList);
          entryToSelect++;
        }
      } while( (compare == false) && (entryToSelect < lemmaName.length) );
      if(compare == true)
      {
        entryToSelect--;
      }      
    }

    
    if(entryToSelect < lemmaName.length)
    {
      //select entry
      listView.setSelectedIndex(entryToSelect);
    }
  }
  
  /**
  reacts on removing in the search-textfield
  calls changedUpdate()
  */
  public void removeUpdate(DocumentEvent event)
  {
    //changedUpdate(event);
  }
  /**
  reacts on insert-actions in the search-textfield
  calls changedUpdate()
  */
  public void insertUpdate(DocumentEvent event)
  {
    changedUpdate(event);
  }
  
  /**
  reacts to changes in the selection of the list by showing the new entry
  */
  public void valueChanged(ListSelectionEvent event)
  {
    JList callingList;
    byte[] stringBuffer;
    String entryString;
    callingList =  (JList) event.getSource();
    int index = callingList.getSelectedIndex();
    
    long begin = lemmaBegin[index];
    long length = (lemmaEnd[index]-lemmaBegin[index])+1;
    if(index > -1)
    {
      try
      {
      //slice out the entry
      stringBuffer = new byte[(int) length];
      dicmlAccess.seek(begin);
      dicmlAccess.readFully(stringBuffer, 0, (int) length);
      entryString = new String(stringBuffer);
      tDicml.parse(entryString);
      }
      catch (Exception e)
      {
         JOptionPane.showMessageDialog(this,  "Fehler beim Auswerten des Eintrags:\n" + e.getMessage(), "FEHLER", JOptionPane.ERROR_MESSAGE);
      }
    }
  }
  
	public static void main(String[] args) {
		OwlReader window;
		window = new OwlReader();
	}
}
/* Stuff from sun.com don't really know what to do with it :-( */
/*
	public static void main(String[] args) {
		OwlTest window;
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
       public void run() {
              createAndShowGUI();
       }
		});
	}
*/


