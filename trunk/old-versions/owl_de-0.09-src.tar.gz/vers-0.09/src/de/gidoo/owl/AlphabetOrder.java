/*
 * AlphabetOrder.java
 *
 * Created on 16. Februar 2005, 19:40
 */

package de.gidoo.owl;

import org.jdom.*;
import java.util.*;

/**
 *
 * @author thomas
 */
public class AlphabetOrder implements java.util.Comparator {
   
    
    private Document doc;
    
    private HashMap charOrder;
    
    /** Creates a new instance of AlphabetOrder */
    public AlphabetOrder(java.io.File orderFile) throws java.io.IOException
    {
      // parse the XML-Content
      try
      {
        org.jdom.input.SAXBuilder builder = new org.jdom.input.SAXBuilder();
        doc = builder.build(orderFile);
        
        // create the order of the chars
                
        Element order = doc.getRootElement().getChild("order");
        List ch = order.getChildren("char");
        int countCh = ch.size();
        
        charOrder = new HashMap(countCh);
        
        int x = 0;
        
        while(x < countCh)
        {
          Element subEl = (Element) ch.get(x);
          // captial letters
          Integer number = new Integer((int) UnicodeHelpers.hexStringToLong(subEl.getAttributeValue("capital")));
          charOrder.put(number, x);
          // small letters
          number = new Integer((int) UnicodeHelpers.hexStringToLong(subEl.getAttributeValue("small")));
          charOrder.put(number, x); 
          x++;
        }
        
      }
      catch(java.io.IOException ioE)
      {
          throw(ioE);
      }
      catch(JDOMException jdE)
      {
          throw(new java.io.IOException("JDOM: " + jdE.getMessage()));
      }
      
    }
    
    public int compare(Object o1, Object o2)
    {
      // convert to strings
      Entry entry1 = (Entry) o1;
      Entry entry2 = (Entry) o2;
      
      // this will become the comparation strings
      String comp1 = UnicodeHelpers.glyphToUnicode(entry1.compare);
      String comp2 = UnicodeHelpers.glyphToUnicode(entry2.compare);
      
      // make all replacements
      Element repl = doc.getRootElement().getChild("replacement");
            
      List group = repl.getChildren("treat.gr");
      int countGroup = group.size();
      for(int x = 0; x < countGroup; x++)
      {
        Element e1 = (Element) group.get(x);
        List treat = e1.getChildren("treat");
        
        Element as = e1.getChild("as");
        String replacement = UnicodeHelpers.glyphToUnicode(as.getTextTrim());
        
        int countTreat = treat.size();
        // replace all
        for(int y = 0; y < countTreat; y++)
        {
          Element e2 = (Element) treat.get(y);
          
          String source = UnicodeHelpers.glyphToUnicode(e2.getTextTrim());
          comp1 = comp1.replaceAll(source, replacement);
          comp2 = comp2.replaceAll(source, replacement);
        }
      }
      
      // and now to s.th completely different:
      // compare!
      
      // go through every char-position
      int minCount = Math.min(comp1.length(), comp2.length());
      int z = 0;
      while(z < minCount)
      {
        char ch1 = comp1.charAt(z);
        char ch2 = comp2.charAt(z);
       
        int result = compareChar(ch1, ch2);
       
        if(result < 0)
        {
          return -1;              
        }
        else if(result > 0)
        {
          return 1;
        }
         
        z++;          
      }
      
      // both seem to be equal up to the minimal length
      // --> decide after the length
      
      if(comp1.length() < comp2.length())
      {
        return -1;
      }
      else if(comp1.length() > comp2.length())
      {
        return 1;         
      }
      
      // the strings are absoutely equal
      
      return 0;
    }
    
    private int compareChar(char comp1, char comp2)
    {
      Integer c1 = new Integer((int) comp1);
      Integer c2 = new Integer((int) comp2);
      
      Integer i1 = (Integer) charOrder.get(c1);
      Integer i2 = (Integer) charOrder.get(c2);
      
      if(i1== null)
      {
        // is not in the list --> give it the worst number
          i1 = new Integer(charOrder.size() + 1);
      }
      if(i2 == null)
      {
        // is not in the list --> give it the worst number
          i2 = new Integer(charOrder.size() + 1);
      }
      return i1.compareTo(i2);
    }
}
