/*
 * Entry.java
 *
 * Created on 20. Februar 2005, 18:27
 */

package de.gidoo.owl;

/**
 *
 * @author thomas
 */
public class Entry {
   
    
   public String lemma;
   public String compare;
   public long start;
   public long end;
    
    /** Creates a new instance of Entry */
    public Entry() {
    }
   
    public String toString()
    {
      return this.lemma;
    }
}
