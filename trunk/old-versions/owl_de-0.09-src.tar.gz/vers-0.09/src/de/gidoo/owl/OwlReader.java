/**
 * OwlReader.java
 *
 * (c) 2004 by Thomas Krause
 * All rights reserved.
 *
 * http://owl.gidoo.de/source
 */


package de.gidoo.owl;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.*;
import javax.swing.text.*;
import java.io.*;
import java.text.*;
import javax.xml.transform.*;
import java.net.*;
/**
 * OwlReader holds the main-window of the owl-reader
 */
class OwlReader extends JFrame implements ActionListener, ListSelectionListener, DocumentListener {
    private JList listView;
    private JTextField tSearch;
    private DicmlRead tDicml;
    private JMenuBar mainMenuBar;
    
    Properties props;
    ResourceBundle i18n;
    
    
    private String lemmaName[];
    private long lemmaBegin[], lemmaEnd[];
    
//    private LinkedList entryList;
    private String sourceLanguage;
    private AlphabetOrder alphOrder;
    
    private RandomAccessFile dicmlAccess;
    
    private ClassLoader loader;
    
    //constructor
    OwlReader() throws java.io.IOException {
     
        
        loader = this.getClass().getClassLoader();
        
        
        //i18n
        try {
            i18n = ResourceBundle.getBundle("de.gidoo.owl.OwlReader");
        } catch (Exception e) {
            String msg_en =   "Error when reading the language file.\nThe programm will exit, since this is a serious error.";
            String msg_de =   "Beim Einlesen der Sprachdatei ist ein Fehler aufgetreten.\nDa dies ein schwerwiegender Fehler ist, wird das Programm beendet.";
            String msg_line = "----------------------------------------------------------------------------------------------------------------";
            JOptionPane.showMessageDialog(this, msg_en + "\n" + msg_line + "\n" + msg_de + "\n" + msg_line + "\n" + e.getLocalizedMessage() , "ERROR | FEHLER", JOptionPane.ERROR_MESSAGE);
            System.exit(2);
        }
        
        sourceLanguage = "de";
        
        //properties
        try 
        {                                 
            props = new Properties();
            props.loadFromXML(loader.getResourceAsStream("etc/owl-reader.config"));
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this, i18n.getString("errorLoadConf") + "\n" + e.getMessage(), i18n.getString("errorTitle"), JOptionPane.ERROR_MESSAGE);
            //TODO: create an empty Property-File
            
        }
                
        // GUI
        
        // set fonts to non-bold by standard
        UIManager.put("swing.boldMetal", Boolean.FALSE); 
        
        // init WindowManager
        GridBagLayout layout = new GridBagLayout();
        setLayout(layout);
        
        //init listView
        GridBagConstraints constraint = new GridBagConstraints();
        String[] LISTDATA = {""};
        listView = new JList(LISTDATA);
        constraint.gridx = 0;
        constraint.gridy = 1;
        constraint.gridwidth = 1;
        constraint.gridheight = 1;
        constraint.ipadx = 120;
        constraint.weightx = 10;
        constraint.weighty = 100;
        constraint.fill = GridBagConstraints.BOTH;
        constraint.anchor = GridBagConstraints.NORTHEAST;
        listView.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listView.addListSelectionListener(this);
        JScrollPane scrollPane = new JScrollPane(listView);
        layout.setConstraints(scrollPane, constraint);
        add(scrollPane);
        
        //init tSearch
        constraint = new GridBagConstraints();
        tSearch = new JTextField("");
        constraint.gridx = 0;
        constraint.gridy = 0;
        constraint.gridwidth = 1;
        constraint.gridheight = 1;
        constraint.weightx = 10;
        constraint.weighty = 0;
        constraint.ipadx = 100;
        constraint.insets = new Insets(0, 0, 10, 0);
        constraint.fill = GridBagConstraints.BOTH;
        constraint.anchor = GridBagConstraints.NORTHEAST;
        layout.setConstraints(tSearch, constraint);
        tSearch.getDocument().addDocumentListener(this);
        add(tSearch);
        
        //init tDicml
        constraint = new GridBagConstraints();
        tDicml = new DicmlRead();
        constraint.gridx = 1;
        constraint.gridy = 0;
        constraint.gridwidth = 1;
        constraint.gridheight = 2;
        constraint.weightx = 100;
        constraint.weighty = 100;
        constraint.fill = GridBagConstraints.BOTH;
        constraint.anchor = GridBagConstraints.NORTHEAST;
        constraint.insets = new Insets(0, 10, 0, 0);
        layout.setConstraints(tDicml, constraint);
        add(tDicml);
        
        //finalize
        pack();
        
        //init menubar
        mainMenuBar = new JMenuBar();
        mainMenuBar.add(createMainMenu());
        
        //init window
        setJMenuBar(mainMenuBar);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle(i18n.getString("progName") + " " + i18n.getString("progVers"));
        setSize(600, 400);
        setVisible(true);
        
        try 
        {                                 
          // when first use, show info-dialog
          File file = new File(System.getProperty("user.home") + "/.owl/foo");
          if(!file.exists())
          {
            InfoDialog dlg = new InfoDialog(this, true);
            dlg.setVisible(true);
            
            file.createNewFile();
            FileWriter writer = new FileWriter(file);
            writer.close();
          }
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this, i18n.getString("errorLoadConf") + "\n" + e.getMessage(), i18n.getString("errorTitle"), JOptionPane.ERROR_MESSAGE);
        } 
        
    }
    
    private JMenu createMainMenu() {
        JMenu menu = new JMenu(i18n.getString("menuMenu"));
        JMenuItem mi;
        
        //open dictionary
        mi = new JMenuItem(i18n.getString("menuOpen"), i18n.getString("menuOpenChar").charAt(0));
        mi.addActionListener(this);
        mi.setActionCommand("opendic");
        menu.add(mi);
        
        // printing
        mi = new JMenuItem(i18n.getString("menuPrint"), i18n.getString("menuPrintChar").charAt(0));
        mi.addActionListener(this);
        mi.setActionCommand("print");
        menu.add(mi);
        
        //infos
        mi = new JMenuItem(i18n.getString("menuInfo"), i18n.getString("menuInfoChar").charAt(0));
        mi.addActionListener(this);
        mi.setActionCommand("info");
        menu.add(mi);
        
        //quit
        mi = new JMenuItem(i18n.getString("menuQuit"), i18n.getString("menuQuit").charAt(0));
        mi.addActionListener(this);
        mi.setActionCommand("quit");
        menu.add(mi);
        return menu;
    }
    
    private void openDictionary() {
        File fileDicml;
        String pathId;
        File fileId;
        IndexDicml indexDialog;
        
        //show file-selector
        
        //TODO: add copyright notice to documentation (IMPORTANT!!! :-) )
        ExampleFileFilter filter = new ExampleFileFilter();
        filter.addExtension("dicml");
        filter.setDescription(i18n.getString("filechooseDicml"));
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(filter);
        
        if(fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION ) {
            fileDicml = fileChooser.getSelectedFile();
            pathId = fileDicml.getAbsolutePath() + ".id";
            fileId = new File(pathId);
            if(fileId.exists()) {
                openDicFile(fileDicml);
                
            } else {
                //ask the user
                if(JOptionPane.showConfirmDialog(this, MessageFormat.format(i18n.getString("filechooseQuestion"), fileDicml.getName()), i18n.getString("progName"), JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    //show indexing dialog
                    indexDialog = new IndexDicml(fileDicml.getAbsolutePath() ,this, true);
                    
                    if(!indexDialog.errorOccured)
                    {
                      openDicFile(fileDicml);
                    }
                }
            }
        }
    }
    
    public void openDicFile(File f) {
        LineNumberReader idReader;
        String line;
        int lineCount=0;
        int entryCount=0;
        
        try {
            if(dicmlAccess != null) {
                //close old dicml-file
                dicmlAccess.close();
            }
            //open dicml-file for accessing
            dicmlAccess = new RandomAccessFile(f, "r");
            
            //count the lines
            idReader = new LineNumberReader(new FileReader(f.getAbsolutePath() + ".id"));

            while(idReader.readLine() != null)
            {
              lineCount++;
            }    
            
            idReader.close();
            //read in the list of entries
            
            idReader = new LineNumberReader(new FileReader(f.getAbsolutePath() + ".id"));
            
            entryCount = lineCount / 3;
            
            //init arrays
            lemmaName = new String[entryCount];
            lemmaBegin = new long[entryCount];
            lemmaEnd = new long[entryCount];
            
            
            for(int x = 0; x < entryCount; x++) {
                
                //add entry to array
                
                line = idReader.readLine();
                lemmaName[x] = line;
                line = idReader.readLine();
                lemmaBegin[x] = Long.parseLong(line);
                line = idReader.readLine();
                lemmaEnd[x] = Long.parseLong(line);
                
            }
                      
            listView.setListData(lemmaName);
            
            idReader.close();
            
            // init the alphabetical Order
            alphOrder = new AlphabetOrder(new File(System.getProperty("user.home") + "/.owl/res/" + sourceLanguage + ".order.xml"));
        
            
            // select first entry
            listView.setSelectedIndex(0);
        } catch(Exception e) {
            if(e.getMessage().equals("-1")) {
                //some kind of selection error, just ignore it
            } else {
                
                e.printStackTrace();
                
                JOptionPane.showMessageDialog(this,  i18n.getString("errorLoadWordbook") + "\n\n" + e.getMessage(), i18n.getString("errorTitle"), JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /**
  react to various action-based events
     */
    public void actionPerformed(ActionEvent event) {
        String cmd = event.getActionCommand();
        if(cmd.equals("opendic")) {
            openDictionary();
        } else if(cmd.equals("print")) {
            printEntry();
        } else if(cmd.equals("info")) {
            //show info dialog
            InfoDialog dlg = new InfoDialog(this, true);
            dlg.setVisible(true);
            //JOptionPane.showMessageDialog(this, MessageFormat.format(i18n.getString("infoText"),  i18n.getString("progName"), i18n.getString("progVers")), i18n.getString("infoTitle"),JOptionPane.INFORMATION_MESSAGE);
        } else if(cmd.equals("quit")) {
            //quit
            System.exit(0);
        }
    }
    
    public void printEntry()
    {
      if(dicmlAccess != null)
      {
        Toolkit tk = Toolkit.getDefaultToolkit();
        PrintJob pj = tk.getPrintJob( new Frame(), "dicml-entry:", null);
        if(pj != null)
        {  
          Graphics g = pj.getGraphics();
                
          // print the view
          // TODO: needs improvement
          tDicml.print(g);
        
          // and finally print
          pj.end();
        }
      }
      else
      {
        JOptionPane.showMessageDialog(this, i18n.getString("errorNotLoadedYet"), i18n.getString("errorTitle"), JOptionPane.ERROR_MESSAGE);
      }
    }
    
    /**
  reacts on changings in the search-textfield
     */
    public void changedUpdate(DocumentEvent event)
    {
      int curIndex = listView.getSelectedIndex();
      
      if(curIndex < 0) {curIndex = 0;}
      
      String text = tSearch.getText();
      
      int newSel = listView.getNextMatch(text, 0, Position.Bias.Forward);
      
      if(newSel >= 0)
      {
        listView.setSelectedIndex(newSel);
        listView.ensureIndexIsVisible(newSel);
      }           
        // old fashioned way
        /* 
        char charTextField = '\u0000';
        char charEntryList = '\u0000';
        String enteredText = tSearch.getText().toLowerCase();
        int entryToSelect = 0;
        boolean compare = false;
        //for every character in enteredText
        for(int i=0; i < enteredText.length(); i++) {
            charTextField = enteredText.charAt(i);
            //compare the i-th character of the entered text with the i-th one of the entry of the list
            do
            {
                if(entryToSelect < lemmaName.length) {
                    int lemmaLength = lemmaName[entryToSelect].length();
                    if(i < lemmaLength) {
                        charEntryList = lemmaName[entryToSelect].toLowerCase().charAt(i);
                    } else {
                        charEntryList = lemmaName[entryToSelect].toLowerCase().charAt(lemmaLength-1);
                    }
                    compare = (charTextField == charEntryList);
                    entryToSelect++;
                }
            } while( (compare == false) && (entryToSelect < lemmaName.length) );
            if(compare == true) {
                entryToSelect--;
            }
        }
        
        
        if(entryToSelect < lemmaName.length) {
            //select entry
            listView.setSelectedIndex(entryToSelect);
        }
         */
    }
    
    /**
  reacts on removing in the search-textfield
  calls changedUpdate()
     */
    public void removeUpdate(DocumentEvent event)
    {
      int curIndex = listView.getSelectedIndex();
      
      if(curIndex < 0) {curIndex = 0;}
      
      String text = tSearch.getText();
      
      int newSel = listView.getNextMatch(text, 0, Position.Bias.Forward);
      
      if(newSel >= 0)
      {
        listView.setSelectedIndex(newSel);
        listView.ensureIndexIsVisible(newSel);
      }
    }
    /**
  reacts on insert-actions in the search-textfield
  calls changedUpdate()
     */
    public void insertUpdate(DocumentEvent event)
    {
      int curIndex = listView.getSelectedIndex();
      
      if(curIndex < 0) {curIndex = 0;}
      
      String text = tSearch.getText();
      
      int newSel = listView.getNextMatch(text, curIndex, Position.Bias.Forward);
      
      if(newSel >= 0)
      {
        listView.setSelectedIndex(newSel);
        listView.ensureIndexIsVisible(newSel);
      }
    }
    
    /**
  reacts to changes in the selection of the list by showing the new entry
     */
    public void valueChanged(ListSelectionEvent event) {
        JList callingList;
        byte[] stringBuffer;
        String entryString;
        callingList =  (JList) event.getSource();
        int index = callingList.getSelectedIndex();
        
        long begin = lemmaBegin[index];
        long length = (lemmaEnd[index] - begin) + 1;
        if(index > -1) {
            try {
                //slice out the entry
                stringBuffer = new byte[(int) length];
                dicmlAccess.seek(begin);
                dicmlAccess.readFully(stringBuffer, 0, (int) length);
                entryString = new String(stringBuffer);
                tDicml.parse(entryString);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,  "Fehler beim Auswerten des Eintrags:\n" + e.getMessage(), "FEHLER", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    public static void main(String[] args) throws java.io.IOException
    {
        OwlReader window;
        window = new OwlReader();
    }
}


