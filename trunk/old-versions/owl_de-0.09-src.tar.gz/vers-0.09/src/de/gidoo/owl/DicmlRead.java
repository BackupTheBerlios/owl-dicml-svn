/**
DicmlRead.java

(c) 2004 by Thomas Krause
All rights reserved.

http://owl.gidoo.de/source
*/

package de.gidoo.owl;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import javax.xml.transform.*;
import java.net.*;
import java.io.*;

import java.util.jar.*;

class DicmlRead extends JPanel implements HyperlinkListener
{
  private JEditorPane dicmlView;
  private Transformer transformer;
  private TransformerFactory tFactory;
  private File emptyFile;
  
  private ClassLoader loader;

  DicmlRead()
  {      
    loader = this.getClass().getClassLoader();
    setLayout(new GridLayout());
    dicmlView = new JEditorPane();
    dicmlView.setVisible(true);
    dicmlView.setEditable(false);
    dicmlView.setContentType("text/html"); 
    setBackground(new Color(255, 0, 0));
    
    dicmlView.addHyperlinkListener(this);
    
    JScrollPane scrollPane = new JScrollPane(dicmlView);
    add(scrollPane);    
    try
    {
      File resDir = new File(System.getProperty("user.home") + "/.owl/res/");
      if(!resDir.exists())
      {
        resDir.mkdirs();
        // copy all files
        
      }
      File owlDir = new File(System.getProperty("user.home") + "/.owl/etc");
      
      if(!owlDir.exists())
      {
        owlDir.mkdirs();
      }
      emptyFile = copyResourceFile("res/empty.html");
      copyResourceFile("res/de.order.xml");
      copyResourceFile("res/fr.order.xml");
      copyResourceFile("res/en.order.xml");
    }
    catch(Exception e)
    {
      System.out.println("error: " + e.getMessage());
    }
    //init XSLT
    try
    {
      
      copyResourceFile("etc/css.css");
        
      dicmlView.setPage(emptyFile.toURL());
      tFactory = TransformerFactory.newInstance();

    transformer =
      tFactory.newTransformer
         (new javax.xml.transform.stream.StreamSource
            (loader.getResourceAsStream("xsl/style.xsl")));
    }
    catch (Exception e)
    {
      JOptionPane.showMessageDialog(this,  "Fehler beim XSLT-Transformationsvorgang:\n" + e.getMessage(), "FEHLER", JOptionPane.ERROR_MESSAGE);
    
    }
  }
  
  /**
   * used to get links and show tooltips at abbrivations
   *
   */
  
  public void hyperlinkUpdate(HyperlinkEvent evt)
  {
    String address = "";
    String title = "";
    java.awt.Graphics gc;
    java.awt.Point mousePos;
        
    // look what kind of action
        
    HyperlinkEvent.EventType type = evt.getEventType();
    if(type == HyperlinkEvent.EventType.ENTERED)
    {
      // just ENTERED
      address = evt.getDescription();
                   
      if(address.startsWith("?abbr:"))
      {
        title = address.substring(6);
              
        gc = getGraphics();
        mousePos = getMousePosition();
            
        update(gc);
        java.awt.Color oldColor = gc.getColor();
        java.awt.Color newColor = new java.awt.Color(255, 200, 0);
         
        // inner rectangle
        gc.setColor(newColor);
        java.awt.FontMetrics fm = gc.getFontMetrics();
          
        int rectX = mousePos.x;
        int rectY = mousePos.y - fm.getHeight() + fm.getDescent();
        int rectHeight = fm.getHeight();
        int rectWidth = fm.stringWidth(title);
            
        gc.fillRect(rectX, rectY, rectWidth, rectHeight);
            
        // bounds
        newColor = new java.awt.Color(0, 0, 0);
        gc.setColor(newColor);
        gc.drawRect(rectX - 1, rectY - 1, rectWidth + 1, rectHeight + 1);
           
        // text
        newColor = new java.awt.Color(0, 0, 0);
        gc.setColor(newColor);            
        gc.drawString(title, mousePos.x, mousePos.y);
        gc.setColor(oldColor);
      }
    }
    else if(type == HyperlinkEvent.EventType.EXITED)
    {
      // just EXITED
      address = evt.getDescription();
      if(address.startsWith("?abbr:"))
      {
        gc = getGraphics();
        update(gc);
      }
    }
        
  }
  
  public void parse(String text)
  {
    try
    {       
        File resultFile = copyResourceFile("etc/entry.html");        
        
        transformer.transform
            (new javax.xml.transform.stream.StreamSource(new StringReader(text)),
                new javax.xml.transform.stream.StreamResult
                    (new FileOutputStream(System.getProperty("user.home") + "/.owl/etc/entry.html"))); 
            
        dicmlView.setPage(emptyFile.toURL());
        dicmlView.setPage(resultFile.toURL());
    }
    catch (Exception e)
    {
      JOptionPane.showMessageDialog(this,  "Fehler beim Aufrufen des Eintrags:\n" + e.getMessage(), "FEHLER", JOptionPane.ERROR_MESSAGE);
    
    }
    
    /*
    //test XSLT
    try {
    TransformerFactory tFactory = TransformerFactory.newInstance();

    Transformer transformer =
      tFactory.newTransformer
         (new javax.xml.transform.stream.StreamSource
            ("style.xsl"));

    transformer.transform
      (new javax.xml.transform.stream.StreamSource
            ("en-de_head.xml"),
       new javax.xml.transform.stream.StreamResult
            ( new FileOutputStream("test.html"))); 
   
    }
    catch (Exception e) {
 //     e.printStackTrace( );
      JOptionPane.showMessageDialog(this,  "Fehler beim XSLT-Transformationsvorgang:\n" + e.getMessage(), "FEHLER", JOptionPane.ERROR_MESSAGE);
    
    }
    */
    /*
    try
    {
      File pageFile = new File("test.html");
//      dicmlView.setText(pageFile.toURI().toString());
      dicmlView.setPage(pageFile.toURI().toString());
    }
    catch (Exception e)
    {
    JOptionPane.showMessageDialog(this,  "Fehler beim Aufrufen des Eintrags:\n" + e.getMessage(), "FEHLER", JOptionPane.ERROR_MESSAGE);
    
    }
    */
  }

  private File copyResourceFile(String path) throws IOException
  {
      File file = new File(System.getProperty("user.home") + "/.owl/" + path);
      if(!file.exists())
      {
        file.createNewFile();
        FileWriter writer = new FileWriter(file);
        InputStream is = loader.getResourceAsStream(path);
        int buffer;
        while((buffer = is.read()) > -1)
        {
          writer.write(buffer);
        }
        writer.close();
      }
      return file;
  }
  
}
