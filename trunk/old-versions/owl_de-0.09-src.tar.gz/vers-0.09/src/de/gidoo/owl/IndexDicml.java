/**
IndexDicml.java

(c) 2004 by Thomas Krause
All rights reserved.

http://owl.gidoo.de/source
*/

package de.gidoo.owl;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;

/**
IndexDicml holds the dialog and routines for indexing a dicML-File
*/
class IndexDicml extends JDialog implements ActionListener 
{
  public ResourceBundle i18n;
  
  JLabel lInfo;
  JProgressBar pbStatus;
  JButton btOk, btAbort;
  
  public boolean errorOccured;
  
  private File dicmlFile;
  
  private IndexDicmlWork workerThread;
  
  IndexDicml(String pathToFile, Frame owner, boolean modal)
  {
    super(owner, modal);
    
    errorOccured = false;
    
    //i18n
    try {
      i18n = ResourceBundle.getBundle("de.gidoo.owl.OwlReader");
    } catch (Exception e) {
      String msg_en =   "Error when reading the language file.\nThe programm will exit, since this is a serious error.";
      String msg_de =   "Beim Einlesen der Sprachdatei ist ein Fehler aufgetreten.\nDa dies ein schwerwiegender Fehler ist, wird das Programm beendet.";
      String msg_line = "----------------------------------------------------------------------------------------------------------------";
      JOptionPane.showMessageDialog(this, msg_en + "\n" + msg_line + "\n" + msg_de + "\n" + msg_line + "\n" + e.getLocalizedMessage() , "ERROR | FEHLER", JOptionPane.ERROR_MESSAGE);
      System.exit(2);
    }
    
    GridBagLayout gbl = new GridBagLayout();
    GridBagConstraints gbc;
    setLayout(gbl);
    
    gbc = new GridBagConstraints();
    lInfo = new JLabel();
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets(1, 1, 1, 1);
    gbl.setConstraints(lInfo, gbc);
    add(lInfo);
    
    dicmlFile = new File(pathToFile);
    lInfo.setText(i18n.getString("indexFile1") + dicmlFile.getName() + i18n.getString("indexFile2"));
    
    gbc = new GridBagConstraints();
    pbStatus = new JProgressBar(JProgressBar.HORIZONTAL, 0, 100);
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.gridwidth = 2;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets(1, 1, 1, 1);
    gbl.setConstraints(pbStatus, gbc);
    pbStatus.setStringPainted(true);
    pbStatus.setString("0%");
    pbStatus.setValue(0);
    add(pbStatus);

    gbc = new GridBagConstraints();
    btOk = new JButton(i18n.getString("indexOk"));
    gbc.gridx = 0;
    gbc.gridy = 2;
    gbc.gridwidth = 1;
    gbc.anchor = GridBagConstraints.WEST;
    gbc.fill = GridBagConstraints.NONE;
    gbc.insets = new Insets(1, 1, 1, 1);
    gbl.setConstraints(btOk, gbc);
    btOk.setEnabled(false);
    btOk.addActionListener(this);
    btOk.setActionCommand("ok");
    add(btOk);

    gbc = new GridBagConstraints();
    btAbort = new JButton(i18n.getString("indexAbort"));
    gbc.gridx = 1;
    gbc.gridy = 2;
    gbc.gridwidth = 1;
    gbc.anchor = GridBagConstraints.EAST;
    gbc.fill = GridBagConstraints.NONE;
    gbc.insets = new Insets(1, 1, 1, 1);
    btAbort.setEnabled(true);
    btAbort.addActionListener(this);
    btAbort.setActionCommand("abort");
    gbl.setConstraints(btAbort, gbc);
    add(btAbort);
 
    pack();
    
    
    //setSize(500, 100);
    setTitle(i18n.getString("indexState"));
    this.setLocation(100, 100);
    
    //start new worker-thread
 
    workerThread = new IndexDicmlWork(dicmlFile, this);
    workerThread.start();
    
    setVisible(true);
  }
  
  public void actionPerformed(ActionEvent e)
  {
    if(e.getActionCommand().equals("ok"))
    {
      setVisible(false);
      dispose();
    }
    else if(e.getActionCommand().equals("abort"))
    {
      workerThread.abort = true;
    }
}
    
  
  public void setStatusBarValue(int alreadyDone)
  {
    if(alreadyDone > 200)
    {
      // an error occured
      errorOccured = true;
      
      btAbort.setEnabled(false);
      btOk.setEnabled(true);
      lInfo.setText(i18n.getString("indexFinishedError"));
      pbStatus.setIndeterminate(false);
      pbStatus.setValue(100);
      pbStatus.setString("100%");
      pack();
    }
    else if(alreadyDone > 100)
    {
      btAbort.setEnabled(false);
      btOk.setEnabled(true);
      lInfo.setText(i18n.getString("indexFinished"));
      pbStatus.setIndeterminate(false);
      pbStatus.setValue(100);
      pbStatus.setString("100%");
      pack();
    }
    else if(alreadyDone == 80)
    {
      pbStatus.setIndeterminate(true);
      btAbort.setEnabled(false);
      pbStatus.setValue(80);
      lInfo.setText(i18n.getString("indexSorting"));
      pack();     
    }
    else if(alreadyDone == 90)
    {
      btAbort.setEnabled(false);
      pbStatus.setIndeterminate(true);
      pbStatus.setValue(80);
      lInfo.setText(i18n.getString("indexWriting"));
      pack();
    }
    else
    {
      pbStatus.setValue(alreadyDone);
      pbStatus.setString(new String().valueOf(alreadyDone) + "%");
    }
  }
  
  
  protected void finalize()
  {
   // dicmlFile.finalize();
  }
}
