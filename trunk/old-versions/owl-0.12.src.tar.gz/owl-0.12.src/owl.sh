# starts owl, please don't start owl.jar directly or make sure that this 
# directory is the working-directory
cd $INSTALL_PATH
java -jar bin/owl.jar $1