//(c) 2004 by Thomas Krause

#include "reader-wndMain.h"

#define NEW_MEM 1

#define _ intl.gettext_by_id

void wndMain::init(gchar* path) {
	    	
	GtkWidget *box1;
	GtkWidget *box2;
	GtkWidget *scroll;
	GtkWidget *main_box;
	GtkWidget *menu;

	GtkAction *action_buffer;
	GtkActionGroup *action_group;
	GtkUIManager *ui_manager;

	PangoFontDescription *font_desc;
	
	owl_path = path;
	
//	g_setenv("LANG", "en_GB", true);

	gchar *lang_code;
	lang_code = g_win32_getlocale();
	gchar *lang_path = g_strdup_printf("%s/etc/owl/%s.lang", owl_path, lang_code);
	gchar *default_lang_path = g_strdup_printf("%s/etc/owl/en_GB.lang", owl_path); 

	if(g_file_test(lang_path, G_FILE_TEST_EXISTS)) {
		intl.load_language(lang_path);
	}
	else {
		intl.load_language(default_lang_path);
	}
	g_free(lang_path);
	g_free(lang_code);
	g_free(default_lang_path);
	
	gtk_rc_parse(g_strdup_printf("%s/etc/owl/gtkrc", owl_path));

	//main window initialisation
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	g_signal_connect(G_OBJECT(window), "delete_event", G_CALLBACK(wndMain::s_delete_event), NULL);
	gtk_window_set_title(GTK_WINDOW(window), _(64));
	gtk_window_set_default_size(GTK_WINDOW(window), 400, 200);

	gtk_window_set_icon_from_file(GTK_WINDOW(window), g_strdup_printf("%s/res/icon.png", owl_path), NULL);

	//actions for the menu
	action_group = gtk_action_group_new("global");

	action_buffer = gtk_action_new("global_menu", _(50), _(50), NULL);
	gtk_action_group_add_action(action_group, action_buffer);

	action_buffer = gtk_action_new("choose_dic", _(51), _(51), NULL);
	g_signal_connect(GTK_ACTION(action_buffer), "activate", G_CALLBACK(wndMain::s_choose_dic_clicked), (wndMain *) this);
	gtk_action_group_add_action_with_accel(action_group, action_buffer, _(65));

	action_buffer = gtk_action_new("info", _(52), _(52), NULL);
	g_signal_connect(GTK_ACTION(action_buffer), "activate", G_CALLBACK(wndMain::s_info_clicked), (wndMain *) this);
	gtk_action_group_add_action_with_accel(action_group, action_buffer, _(66));

	action_buffer = gtk_action_new("quit", _(53), _(53), NULL);
	g_signal_connect(GTK_ACTION(action_buffer), "activate", G_CALLBACK(wndMain::s_delete_event), (wndMain *) this);
	gtk_action_group_add_action_with_accel(action_group, action_buffer, _(67));

	//UI
	ui_manager = gtk_ui_manager_new();
	gtk_ui_manager_add_ui_from_string(ui_manager,
										"<ui><menubar name=\"MenuBar\"><menu name=\"Menu\" action=\"global_menu\"><menuitem name=\"choose_dic\" action=\"choose_dic\"/><menuitem name=\"info\" action=\"info\"/><menuitem name=\"quit\" action=\"quit\"/></menu></menubar></ui>",
										-1, NULL);

	gtk_ui_manager_insert_action_group(ui_manager, action_group, 0);
	gtk_window_add_accel_group(GTK_WINDOW(window), gtk_ui_manager_get_accel_group(ui_manager));
	menu = gtk_ui_manager_get_widget(ui_manager, "/MenuBar");

	main_box = gtk_vbox_new(FALSE, 5);

	//second horizontal box, including the list and the special "interpreter" (right)
	box2 = gtk_hbox_new(FALSE, 5);

	//box2 is devides into box1 (for the search text-entry and the list) and the interpreter
	box1 = gtk_vbox_new(FALSE, 5);

	text_entry = gtk_entry_new();
	g_signal_connect(GTK_ENTRY(text_entry), "changed", G_CALLBACK(wndMain::s_text_entry_changed), (wndMain *) this);
	gtk_box_pack_start(GTK_BOX(box1), text_entry, FALSE, FALSE, 0);
	gtk_widget_show(text_entry);

	setup_list(box1);

	gtk_box_pack_start(GTK_BOX(box2), box1, FALSE, FALSE, 0);

	gtk_widget_set_size_request(GTK_WIDGET(box1), 150, 0);

	gtk_widget_show(box1);
	interpreter.init(box2, owl_path);
	gtk_widget_show(box2);

	//show the window or no one will see the "masterpiece" ;-)
	gtk_box_pack_start(GTK_BOX(main_box), menu, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(main_box), box2, TRUE, TRUE, 0);

//	gtk_widget_set_size_request(GTK_WIDGET(box2), 100, 100);
	
	gtk_widget_show(menu);
	gtk_widget_show(main_box);
	gtk_container_add(GTK_CONTAINER(window), main_box);

	gtk_widget_show(window);

	g_log_set_handler(NULL, G_LOG_LEVEL_WARNING, s_warning_handler, (wndMain *) this);
}

void wndMain::setup_list(GtkWidget *top_box) {

	GtkWidget *scroll;

	scroll = gtk_scrolled_window_new(NULL, NULL);


	gtk_widget_show(scroll);

	list_store = gtk_list_store_new(1, G_TYPE_STRING);

	list = gtk_tree_view_new_with_model(GTK_TREE_MODEL(list_store));

	list_selection = gtk_tree_view_get_selection (GTK_TREE_VIEW (list));

	renderer = gtk_cell_renderer_text_new ();
    g_object_set (G_OBJECT (renderer),
                 "foreground", "black",
                 NULL);
	column = gtk_tree_view_column_new_with_attributes (NULL, renderer,"text", 0, NULL);

	gtk_tree_view_append_column (GTK_TREE_VIEW (list), column);
	
	gtk_tree_view_set_headers_visible(GTK_TREE_VIEW(list), FALSE);

	gtk_container_add(GTK_CONTAINER(scroll), list);
	gtk_box_pack_start(GTK_BOX(top_box), scroll, TRUE, TRUE, 0);

	gtk_widget_show(list);

	g_signal_connect(G_OBJECT(list_selection), "changed", G_CALLBACK(wndMain::s_list_changed), (wndMain*) this);

}

//event handling member functions (dynamic)
void wndMain::choose_dic_clicked() {

	//old version

/*	GtkWidget *file_selector;


	file_selector = gtk_file_selection_new ("Please select a dictionary file.");
   
	gtk_file_selection_complete(GTK_FILE_SELECTION(file_selector), "*.*");
	

	param.pThis = this;
	param.pWidget = file_selector;
	param.do_after = 0;


	g_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION (file_selector)->ok_button),
                    "clicked",
                    G_CALLBACK (wndMain::s_filedialog_ok),
                    (gpointer) &param); 
   
	g_signal_connect_swapped (GTK_OBJECT (GTK_FILE_SELECTION (file_selector)->ok_button),
                             "clicked",
                             G_CALLBACK (gtk_widget_destroy), 
                             (gpointer) file_selector); 

	g_signal_connect_swapped (GTK_OBJECT (GTK_FILE_SELECTION (file_selector)->cancel_button),
                             "clicked",
                             G_CALLBACK (gtk_widget_destroy),
                             (gpointer) file_selector); 
   
   gtk_widget_show (file_selector);

  */

	//new file-chooser
	GtkWidget * dialog;
	
	dialog = gtk_file_chooser_dialog_new (	_(54),
											GTK_WINDOW(window),
											GTK_FILE_CHOOSER_ACTION_OPEN,
											GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
											GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
											NULL);
	
	GtkFileFilter *filter_dic = gtk_file_filter_new();
	GtkFileFilter *filter_all = gtk_file_filter_new();

	gtk_file_filter_set_name(filter_dic, _(55));
	gtk_file_filter_add_pattern(filter_dic, "*.dicml");

	gtk_file_filter_set_name(filter_all, _(56));
	gtk_file_filter_add_pattern(filter_all, "*.*");

	gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), filter_dic);
	gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), filter_all);

	if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT) {
	
		filepath = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
		gtk_widget_destroy (dialog);
		new_dic();
	}
	else {
		gtk_widget_destroy(dialog);
	}
	
}

void wndMain::text_entry_changed() {

	gchar* entered_text = g_strdup(gtk_entry_get_text(GTK_ENTRY(text_entry)));
	gchar *entered_pt = entered_text;
	glong x = 0;
	gchar *a,*b;
	gchar *a_down, *b_down;
	gchar *a_key,*b_key;
	gchar *array_index;
	gchar *array_index_pt;
	gint compare;
	glong array_pos = 0;
	gchar *number_to_select = g_new(gchar, 255);


	while (*entered_pt) {

		//compare the x-th character of the entered text with the x-th one of the entry of the list 
		a = g_new(gchar, 7);
		g_utf8_strncpy(a, entered_pt, 1);
		*g_utf8_offset_to_pointer(a, 1) = '\0';
		a_down = g_utf8_strdown(a, -1);
		a_key = g_utf8_collate_key(a_down, -1);
		do {
			if(array_pos < entries_count) {
				array_index = g_array_index(entries_lemma, gchar*, array_pos);
				if(g_utf8_strlen(array_index, -1) > x) {
					array_index_pt = g_utf8_offset_to_pointer(array_index, x);
				}
				else {
					array_index_pt = g_utf8_offset_to_pointer(array_index, g_utf8_strlen(array_index, -1));
				}
				b = g_new(gchar, 7);
				g_utf8_strncpy(b, array_index_pt, 1);
				*g_utf8_offset_to_pointer(b, 1) = '\0';
				b_down = g_utf8_strdown(b, -1);
				b_key = g_utf8_collate_key(b_down, -1);
				
				compare = strcmp(a_key, b_key);

				array_pos++;
				g_free(b);
				g_free(b_down);
				g_free(b_key);
			}	
		} while ( (compare != 0) && (array_pos < entries_count) );
		
		if(compare == 0) array_pos--;

		entered_pt = g_utf8_next_char (entered_pt);
		x++;
		g_free(a);
		g_free(a_down);
		g_free(a_key);
	}
		g_free(entered_text);
		
		//select the entry
		if(array_pos < entries_count) {
			g_ascii_dtostr(number_to_select, 255, (gdouble) array_pos);						
			GtkTreePath *path = gtk_tree_path_new_from_string(number_to_select);

//			gtk_tree_model_get_iter_from_string(GTK_TREE_MODEL(list_store), &iter1, number_to_select);
//			gtk_tree_selection_select_iter(GTK_TREE_SELECTION(list_selection), &iter1);
			gtk_tree_view_set_cursor(GTK_TREE_VIEW(list), path, 0, FALSE);
			g_free(path);
		}
		g_free(number_to_select);
}

void wndMain::info_clicked() {
	GtkWidget *dialog;
	
	dialog = gtk_message_dialog_new(GTK_WINDOW(window),
									GTK_DIALOG_DESTROY_WITH_PARENT,
									GTK_MESSAGE_INFO,
									GTK_BUTTONS_OK,
									_(58)
									);
	gtk_dialog_run (GTK_DIALOG (dialog));
	gtk_widget_destroy (dialog);
}



void wndMain::list_changed() {
	
	gint pos_selected = -1;
	GtkTreeModel *model;
	
    if (gtk_tree_selection_get_selected (list_selection, &model, &iter_selected)) {
		
		pos_selected = (gint) g_ascii_strtod(gtk_tree_model_get_string_from_iter(model, &iter_selected), NULL);
	  
		gsize begin = g_array_index(entries_begin, gsize, pos_selected);
		gsize length = g_array_index(entries_end, gsize, pos_selected) - begin;
		gchar* buffer1 = g_new(gchar, 1);

		gsize read;

                GIOStatus status;
    
		//set filepointer to beginning
		status = g_io_channel_seek_position(io_dic, begin,G_SEEK_SET, NULL);
    
		//read out the characters
		
		//1 by 1
		gchar* pt_last_char;
		gsize buf_size = 0;
		
		while( (status != G_IO_STATUS_EOF) && (status != G_IO_STATUS_ERROR) && (buf_size < length)) {
			buffer1 = g_renew(gchar, buffer1, buf_size+1);
			pt_last_char = buffer1 + buf_size;
			status = g_io_channel_read_chars(io_dic, pt_last_char, 1, NULL, NULL);
			buf_size++;
		}
              
		//add the last (and very important!!!) charakter
                buffer1 = g_renew(gchar, buffer1, buf_size+1);
		pt_last_char = buffer1 + buf_size;
		*pt_last_char = '\0';
		//end finally: parse it
		interpreter.parse(buffer1);
	}
}

void wndMain::new_dic() {

	GtkWidget * missing_dialog;

	//look for the ID-file first
	gchar * id_file;

	id_file = g_strdup_printf("%s.id", filepath);
	
	if(g_file_test(id_file, G_FILE_TEST_EXISTS)) {
		read_dic();
	}
	else {
		//inform the user that he has to create an id-file an do so
		missing_dialog = gtk_message_dialog_new	(GTK_WINDOW(window),
												GTK_DIALOG_DESTROY_WITH_PARENT,
												GTK_MESSAGE_WARNING,
												GTK_BUTTONS_YES_NO,
												_(57),
												filepath, filepath);
		gint result = gtk_dialog_run(GTK_DIALOG(missing_dialog));
		gtk_widget_destroy(missing_dialog);
		if(result == GTK_RESPONSE_YES) {
			index_dic();
			read_dic();
		}


	}
}

void wndMain::index_dic() {
	//create a status-dialog
	GtkWidget *status_dialog, *progress_bar, *info_label;
	
	status_dialog = gtk_dialog_new_with_buttons(_(59),
												GTK_WINDOW(window),
												GTK_DIALOG_DESTROY_WITH_PARENT,
												GTK_STOCK_OK,
												GTK_RESPONSE_ACCEPT,
												NULL);

	gtk_window_set_default_size(GTK_WINDOW(status_dialog), 300, 1);



	gtk_window_set_modal(GTK_WINDOW(status_dialog), TRUE);

	gtk_dialog_set_has_separator(GTK_DIALOG(status_dialog), FALSE);
	
	progress_bar = gtk_progress_bar_new();
	info_label = gtk_label_new(NULL);

	gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(progress_bar), 0);

	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(status_dialog)->vbox), info_label);
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(status_dialog)->vbox), progress_bar);
	gtk_widget_show_all(status_dialog);
	gtk_widget_set_sensitive(GTK_DIALOG(status_dialog)->action_area, FALSE);
	
	g_signal_connect_swapped(status_dialog, "response", G_CALLBACK(gtk_widget_destroy), status_dialog);

	//create the id-file
	gtk_label_set_text(GTK_LABEL(info_label), _(60));
	gchar *buffer = g_strdup_printf("%s.id", filepath);
	GIOChannel * id_file;
	id_file = g_io_channel_new_file(buffer, "w+", NULL);
	g_free(buffer);
	
	//open dic-file
	gtk_label_set_text(GTK_LABEL(info_label), _(61));
	
	GIOChannel * dic_file;
	gchar* dic_buf;
	gint dic_size = 0;
	gint dic_buf_size = 0;
	gint dic_entries = 0;
	GIOStatus status;

	dic_file = g_io_channel_new_file(filepath, "r+", NULL);

	//indexing

	gchar *test_buffer;
	gchar *lemma;
	gchar* buf;
	gchar *num_begin;
	gchar *num_end;
	gint num_length;
	gchar *num;
	gchar *buf2;
	gint pos_entry_begin;
	gint pos_entry_end;
	gint pos_l_begin;
	gint pos_l_end;
	gint to_do = 0;
	gchar* found;
	gchar* pt_last_char;

	gtk_label_set_text(GTK_LABEL(info_label), _(62));
	
	dic_buf = g_new(gchar, 1);
	while( (status != G_IO_STATUS_EOF) && (status != G_IO_STATUS_ERROR) ) {
		
		//read in 1 char
		dic_buf = g_renew(gchar, dic_buf, dic_buf_size+1);
		pt_last_char = dic_buf + dic_buf_size;
		status = g_io_channel_read_chars(dic_file, pt_last_char, 1, NULL, NULL);
		
		// <entry
		if(to_do == 0) {
			found = g_strrstr(dic_buf, "<entry");
			if(found != NULL) {
				pos_entry_begin = dic_size - 6 + 1; // count of <entry = 6
				to_do = 1;
			}
		}
	
		// <l>
		if(to_do == 1) {
			found = g_strrstr(dic_buf, "<l>");
			if(found != NULL) {
				pos_l_begin = dic_buf_size + 1;
				to_do = 2;
			}

		}
		// </l>
		if(to_do == 2) {
			found = g_strrstr(dic_buf, "</l>");
			if(found != NULL) {
				test_buffer = dic_buf + pos_l_begin;
				pos_l_end = dic_buf_size - 4 + 1;
				lemma = g_strndup(test_buffer, pos_l_end - pos_l_begin);				
				to_do = 3;
			}

		}
		// </entry>
		if(to_do == 3) {;
			found = g_strrstr(dic_buf, "</entry>");
			if(found != NULL) {
				pos_entry_end = dic_size + 1;

				//search for <num> and </num>
				num_begin = g_strrstr(dic_buf, "<num>");
				num_end = g_strrstr(dic_buf, "</num>");
				
				if((num_begin != NULL) && (num_end != NULL)) {
					num_begin = num_begin + 5;
					num_length = num_end - num_begin;
					num = g_strndup(num_begin, num_length);
					//writing the name (with the <num>-field), beginning and ending of the entry
					buf = g_strdup_printf("%s (%s)\n%d\n%d\n", lemma, num,pos_entry_begin, pos_entry_end);
					g_free(num);
				}
				else {
					//writing the name, beginning and ending of the entry
					buf = g_strdup_printf("%s\n%d\n%d\n", lemma, pos_entry_begin, pos_entry_end);
				}
				//convert special charcters from the form &#xCode; to "real" UTF8
				buf2 = glyph_to_utf8(buf);
//				g_utf8_validate(buf2, -1, NULL);
				g_io_channel_write_chars(id_file, buf2, -1, NULL, NULL);
				g_io_channel_flush(id_file, NULL);
				g_free(lemma);
				g_free(buf);

				g_free(buf2);

//				g_free(dic_buf);
//				dic_buf = g_new(gchar, 1);
				dic_buf = g_renew(gchar, dic_buf, 1);
				dic_buf_size = -1;

				to_do = 0;

				dic_entries++;
				if((dic_entries % 100) == 0) { 
					gtk_progress_bar_pulse(GTK_PROGRESS_BAR(progress_bar));
					while (gtk_events_pending ()) gtk_main_iteration ();
				}
			}
		}


		dic_size++;
		dic_buf_size++;
	}

	g_io_channel_flush(id_file, NULL);
	g_io_channel_unref(id_file);
	g_io_channel_unref(dic_file);

//	g_message("%d", dic_size);
//	g_message("%d", status);
//	g_io_channel_shutdown(id_file, TRUE, NULL);
//	g_io_channel_shutdown(dic_file, TRUE, NULL);

	gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(progress_bar), 1.0);
	gtk_label_set_text(GTK_LABEL(info_label), _(63));

	gtk_widget_set_sensitive(GTK_DIALOG(status_dialog)->action_area, TRUE);
	
	g_free(dic_buf);
}

void wndMain::read_dic() {
	
	gchar *file_buffer;
	gchar *id_path = g_strdup_printf("%s.id", filepath);

	g_file_get_contents(id_path, &file_buffer, NULL, NULL);

	g_free(id_path);


	//split into the several entries
	gchar **array_splitted;								//array_ -> beginning
	gchar **pt_splitted;								//pt_ -> pointer for walking along the entries
	array_splitted = g_strsplit(file_buffer, "\n", 0);
	pt_splitted = array_splitted;

	//sort splitted text in lemma, begin and end
	//but first, free memory
	if(entries_allocated == TRUE) {
		for(int x=0;x<entries_lemma->len; x++) {
			g_free(g_array_index(entries_lemma, gchar*, x));
		}

		g_array_free(entries_lemma, TRUE);
		g_array_free(entries_begin, TRUE);
		g_array_free(entries_end, TRUE);

		//close the io-channel;

		g_io_channel_unref(io_dic);
	}

	entries_lemma = g_array_new(FALSE, FALSE, sizeof(gchar*));
	entries_begin = g_array_new(FALSE, FALSE, sizeof(gint));
	entries_end = g_array_new(FALSE, FALSE, sizeof(gint));
	entries_allocated = TRUE;

	entries_count = 0;

	while((*pt_splitted != NULL) && (g_ascii_strcasecmp(*pt_splitted, "") != 0)) {
			gchar* buf = g_strdup(*pt_splitted);
			g_array_append_val(entries_lemma, buf);
			pt_splitted++;

			gint test1 = (gint) g_ascii_strtod(*pt_splitted, NULL);
			pt_splitted++;
			gint test2 = (gint) g_ascii_strtod(*pt_splitted, NULL);
			g_array_append_val(entries_begin, test1);
			pt_splitted++;
	
			g_array_append_val(entries_end, test2);

			entries_count++;
	}
	
	g_strfreev(array_splitted);

	//update the list-widget

	gtk_list_store_clear(GTK_LIST_STORE(list_store));

	for(int y=0;y<entries_lemma->len;y++) {
		gtk_list_store_append(list_store, &iter1);
		gtk_list_store_set(GTK_LIST_STORE(list_store), &iter1, 0, g_array_index(entries_lemma, gchar*, y),-1);
	}
	
	//open io-channel
	io_dic = g_io_channel_new_file(filepath, "r", NULL);

//	interpreter.parse("<entry><lemma><l>please select an entry</l></lemma></entry>");
}

gchar* wndMain::utf8(gchar * string) {

	return g_locale_to_utf8(string, -1, NULL, NULL, NULL);

}

gchar* wndMain::glyph_to_utf8(gchar * string) {
	//convert special characters from the form &#xCode; to "real" UTF8
	
	gchar *new_string = g_strdup(string);
	gchar *result_string = g_new(gchar, 1);
	*result_string = '\0';
	glong string_length = g_utf8_strlen(new_string, -1);
	gchar *found_ampersand;
	gchar *found_semicolon;
	glong found_length;
	gchar *found_code;
	gunichar found_unichar;
	gchar *buffer1;
	gchar *buffer2;
	gchar *buffer3;
	
	found_ampersand = g_strrstr_len(new_string, string_length, "&#x");
	while( (string_length > 0) && (found_ampersand != NULL) ) {
		found_ampersand = g_utf8_next_char(found_ampersand);
		found_ampersand = g_utf8_next_char(found_ampersand);
		found_ampersand = g_utf8_next_char(found_ampersand);

		found_semicolon = g_strrstr_len(new_string, string_length, ";");
		if(found_semicolon != NULL) {
			found_length = g_utf8_pointer_to_offset(new_string, found_semicolon) - g_utf8_pointer_to_offset(new_string, found_ampersand);
			if(found_length > 0) {
				found_code = g_new(gchar, found_length * 7);
				
				g_utf8_strncpy(found_code, found_ampersand, found_length);
				*g_utf8_offset_to_pointer(found_code, found_length) = '\0';
				found_unichar = hex_str_to_long(found_code);

				buffer1 = g_new(gchar, string_length*7);
				found_semicolon = g_utf8_next_char(found_semicolon);
				g_utf8_strncpy(buffer1, found_semicolon, string_length - g_utf8_pointer_to_offset(new_string, found_semicolon));
				buffer3 = g_new(gchar, 7);
				g_unichar_to_utf8(found_unichar, buffer3);
				*g_utf8_offset_to_pointer(buffer3, 1) = '\0';
				buffer2 = g_strdup_printf("%s%s%s", buffer3, buffer1, result_string);
				g_free(buffer1);
				g_free(buffer3);

				g_free(result_string);
				result_string = buffer2;

				g_free(found_code);
			}

		}

		string_length = g_utf8_pointer_to_offset(new_string, found_ampersand) - 3;
		found_ampersand = g_strrstr_len(new_string, string_length, "&#x");
	}
	if(string_length > 0) {
		buffer1 = g_new(gchar, string_length*7);
		g_utf8_strncpy(buffer1, new_string, string_length);
		buffer2 = g_strdup_printf("%s%s", buffer1, result_string);
		g_free(buffer1);
	
		g_free(result_string);
		result_string = buffer2;
	}
	g_free(new_string);

	return result_string;
}

glong wndMain::hex_str_to_long(gchar *str) {
	//convert strings with hexadecimal values (e.g. "04E4") to glong
	
	
	gchar *new_str = g_utf8_strdown(str, -1);
	glong length = g_utf8_strlen(new_str, -1);
	gunichar chr;
	gshort number;
	glong result = 0;
	while(length > 0) {
		chr = g_utf8_get_char(new_str);
		switch(chr) {
		case '0':
					number = 0;
					break;
		case '1':
					number = 1;
					break;
		case '2':
					number = 2;
					break;
		case '3':
					number = 3;
					break;
		case '4':
					number = 4;
					break;
		case '5':
					number = 5;
					break;
		case '6':
					number = 6;
					break;
		case '7':
					number = 7;
					break;
		case '8':
					number = 8;
					break;
		case '9':
					number = 9;
					break;
		case 'a':
					number = 10;
					break;
		case 'b':
					number = 11;
					break;
		case 'c':
					number = 12;
					break;
		case 'd':
					number = 13;
					break;
		case 'e':
					number = 14;
					break;
		case 'f':
					number = 15;
					break;
		}
		
		result = result + (number * pow(16, length-1));

		length--;
		new_str = g_utf8_next_char(new_str);
	}

	g_free(new_str);
	return result;
}

//static member functions (event and helper)
gint wndMain::s_delete_event(GtkWidget *widget, GdkEvent* event, gpointer data) {
	gtk_main_quit();
	return FALSE;
}

void wndMain::s_choose_dic_clicked(GtkAction *action, gpointer callback_data ) {
	wndMain *pThis = (wndMain *) callback_data;
	pThis->choose_dic_clicked();
}

void wndMain::s_info_clicked(GtkAction *action, gpointer callback_data) {
	wndMain *pThis = (wndMain *) callback_data;

	pThis->info_clicked();
}


void wndMain::s_text_entry_changed(GtkEditable *editable, gpointer user_data) {
	wndMain *pThis = (wndMain *) user_data;

	pThis->text_entry_changed();
}

void wndMain::s_list_changed(GtkTreeSelection *treeselection, gpointer user_data) {

	wndMain *pThis = (wndMain*) user_data;

	pThis->list_changed();

}

void wndMain::s_warning_handler(const gchar *log_domain, GLogLevelFlags log_level, const gchar *message, gpointer user_data) {
	
	//do nothing
/*	g_print("--------------------------------------------------------------------------------Warning:\n");
	g_print(message);
	g_print("\n--------------------------------------------------------------------------------\n\n");
*/
}

void wndMain::print_hello( GtkWidget *w,	gpointer   data ) {

g_message("HALLOOOOO");
}
