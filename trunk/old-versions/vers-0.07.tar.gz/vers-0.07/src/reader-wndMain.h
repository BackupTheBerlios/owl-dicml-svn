#include <gtk/gtk.h>
#include <math.h>
#include <string.h>

#include "dicMlRead.h"

#include "i18n.h"

class wndMain {
public:

	struct struct_param {
		wndMain *pThis;
		GtkWidget *pWidget;
		int do_after;
	};


	void init(gchar* path);

	static gint s_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data);
	static void print_hello( GtkWidget *w, gpointer   data );
	static void s_choose_dic_clicked(GtkAction *action, gpointer callback_data);
	static void s_list_changed(GtkTreeSelection *treeselection, gpointer user_data);
	static void s_info_clicked(GtkAction *action, gpointer callback_data);
	static void s_text_entry_changed(GtkEditable *editable, gpointer user_data);
	static void s_warning_handler(const gchar *log_domain, GLogLevelFlags log_level, const gchar *message, gpointer user_data);
	
private:
	void setup_list(GtkWidget *top_box);
	void choose_dic_clicked();
	void info_clicked();
	void text_entry_changed();
	void list_changed();
	void new_dic();
	void index_dic();
	void read_dic();

	gchar* utf8(gchar * string);
	gchar* glyph_to_utf8(gchar * string);
	glong hex_str_to_long(gchar *str);

	GtkWidget *dicml;
	dicmlRead interpreter;
	GtkWidget *window;
	GtkWidget *text_entry;
	GtkWidget *list;
	GtkListStore *list_store;
	GtkTreeIter iter1;
	GtkTreeIter iter_selected;
	GtkTreeViewColumn *column;
	GtkCellRenderer *renderer;
	GtkTreeSelection *list_selection;
	
	GIOChannel *io_dic;

	struct_param param;
	
	gchar* owl_path;
	gchar* filepath;
	
	GArray *entries_lemma;
	GArray *entries_begin;
	GArray *entries_end;
	gint entries_count;
	gboolean entries_allocated;

	i18n intl;


};
