//OWL-READER
//Vers. 0.07
//(c) 2004 by Thomas Krause
#include <gtk/gtk.h>
#include <stdio.h>
#include <ctype.h>
#include "reader-wndMain.h"
wndMain main_window;

int main( int   argc,
          char *argv[] )
{
const gchar *buffer1;
gchar *buffer2;
gsize pos;
gchar *pPos;
gint gint_pos;

	gtk_init (&argc, &argv);
	
	//get the path to the main directory of "owl"
	buffer1 = g_strdelimit(g_ascii_strdown(g_path_get_dirname(argv[0]), -1), "\\", '/');

	pPos = g_strrstr(buffer1, "/bin");
	gint_pos =  pPos-buffer1;
	if(gint_pos > 0) {
		pos = (gsize) gint_pos;
		buffer2 = g_strndup(buffer1, pos);

		main_window.init(buffer2);
	}
	else {
		g_print("\n\nA serious internal error occured.\nPlease contact the author (thomas.krause@gidoo.de)");
	}

	gtk_main ();

    return 0;
}

//this is for hiding the console window under Win32
//taken from the gtk-maillist (thx a lot)
#ifdef G_OS_WIN32 

#include <windows.h>

static int 
breakargs(char *program, char *line, char **argv) 
{ 
  int argc = 1; 

  argv[0] = program; 

  while(*line) 
  { while(*line && isspace(*line)) 
      line++; 

    if ( *line == '"' )                 /* Windows-95 quoted arguments */ 
    { char *start = line+1; 
      char *end = start; 

      while( *end && *end != '"' ) 
        end++; 
      if ( *end == '"' ) 
      { *end = '\0'; 
        argv[argc++] = start; 
        line = end+1; 
        continue; 
      } 
    } 

    if ( *line ) 
    { argv[argc++] = line; 
      while(*line && !isspace(*line)) 
        line++; 
      if ( *line ) 
        *line++ = '\0'; 
    } 
  } 
  argv[argc] = NULL; /* add trailing NULL pointer to argv */ 

  return argc; 
} 

int WINAPI 
WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nShowCmd) 
{ 
  char *argv[100];                                         
  int  argc;                                               
  TCHAR program[MAXPATHLEN];                               

  GetModuleFileName(hInstance, program, sizeof(program));  
  argc = breakargs((char *)program, lpszCmdLine, argv);    
  main(argc, argv); 
  return 0; 
} 

#endif /*WIN32*/
