#include "editor-wndMain.h"

#define _ intl.gettext_by_id

void wndMain::init(gchar* path) {
	    	
	GtkWidget *box1;
	GtkWidget *box2;
	GtkWidget *scroll;
	GtkWidget *main_box;
	GtkWidget *menu;

	GtkAction *action_buffer;
	GtkActionGroup *action_group;
	GtkUIManager *ui_manager;

	PangoFontDescription *font_desc;
	
	owl_path = path;

	gchar *lang_code;
	lang_code = g_win32_getlocale();
	gchar *lang_path = g_strdup_printf("%s/etc/owl/%s.lang", owl_path, lang_code);
	gchar *default_lang_path = g_strdup_printf("%s/etc/owl/en_GB.lang", owl_path); 

	if(g_file_test(lang_path, G_FILE_TEST_EXISTS)) {
		intl.load_language(lang_path);
	}
	else {
		intl.load_language(default_lang_path);
	}
	g_free(lang_path);
	g_free(lang_code);
	g_free(default_lang_path);
	gtk_rc_parse(g_strdup_printf("%s/etc/owl/gtkrc", owl_path));

	//main window initialisation
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	g_signal_connect(G_OBJECT(window), "delete_event", G_CALLBACK(wndMain::s_delete_event), NULL);
	gtk_window_set_title(GTK_WINDOW(window), _(0));
	gtk_window_set_default_size(GTK_WINDOW(window), 600, 400);
	gtk_window_maximize(GTK_WINDOW(window));

	main_box = gtk_vbox_new(FALSE, 5);
	//first horizontal box, including menue like buttons

	box1 = gtk_hbox_new(FALSE, 5);
	
/*	menue = gtk_toolbar_new();

	gtk_toolbar_set_style(GTK_TOOLBAR(menue), GTK_TOOLBAR_ICONS);

	gtk_toolbar_insert_stock(GTK_TOOLBAR(menue), GTK_STOCK_NEW, _(1), "", G_CALLBACK(s_new_clicked), (gpointer) this, -1);
	gtk_toolbar_insert_stock(GTK_TOOLBAR(menue), GTK_STOCK_OPEN, _(2), "", G_CALLBACK(s_load_clicked), (gpointer) this, -1);
	gtk_toolbar_insert_stock(GTK_TOOLBAR(menue), GTK_STOCK_SAVE, _(3), "tztr", G_CALLBACK(s_save_clicked), (gpointer) this, -1);
	gtk_toolbar_insert_stock(GTK_TOOLBAR(menue), GTK_STOCK_SAVE_AS, _(4), "tztr", G_CALLBACK(s_save_as_clicked), (gpointer) this, -1);
	gtk_toolbar_insert_space(GTK_TOOLBAR(menue), -1);
	gtk_toolbar_insert_stock(GTK_TOOLBAR(menue), GTK_STOCK_EXECUTE, _(5), "tztr", G_CALLBACK(s_render_clicked), (gpointer) this, -1);
	gtk_toolbar_insert_space(GTK_TOOLBAR(menue), -1);
	gtk_toolbar_insert_stock(GTK_TOOLBAR(menue), GTK_STOCK_DIALOG_QUESTION, _(6), "tztr", G_CALLBACK(s_help_clicked), (gpointer) this, -1);
	gtk_toolbar_insert_stock(GTK_TOOLBAR(menue), GTK_STOCK_QUIT, _(7), "tztr", G_CALLBACK(s_delete_event), (gpointer) this, -1);
*/
	//actions for the toolbox
	action_group = gtk_action_group_new("global");

	action_buffer = gtk_action_new("new_file", _(1), _(21), "gtk-new");
	g_signal_connect(GTK_ACTION(action_buffer), "activate", G_CALLBACK(wndMain::s_new_clicked), (wndMain *) this);
	gtk_action_group_add_action_with_accel(action_group, action_buffer, _(14));

	action_buffer = gtk_action_new("open_file", _(2), _(22), "gtk-open");
	g_signal_connect(GTK_ACTION(action_buffer), "activate", G_CALLBACK(wndMain::s_load_clicked), (wndMain *) this);
	gtk_action_group_add_action_with_accel(action_group, action_buffer, _(15));

	action_buffer = gtk_action_new("save_file", _(3), _(23), "gtk-save");
	g_signal_connect(GTK_ACTION(action_buffer), "activate", G_CALLBACK(wndMain::s_save_clicked), (wndMain *) this);
	gtk_action_group_add_action_with_accel(action_group, action_buffer, _(16));
	
	action_buffer = gtk_action_new("save_file_as", _(4), _(24), "gtk-save-as");
	g_signal_connect(GTK_ACTION(action_buffer), "activate", G_CALLBACK(wndMain::s_save_as_clicked), (wndMain *) this);
	gtk_action_group_add_action_with_accel(action_group, action_buffer, _(17));

	action_buffer = gtk_action_new("render", _(5), _(25), "gtk-execute");
	g_signal_connect(GTK_ACTION(action_buffer), "activate", G_CALLBACK(wndMain::s_render_clicked), (wndMain *) this);
	gtk_action_group_add_action_with_accel(action_group, action_buffer, _(18));

	action_buffer = gtk_action_new("info", _(6), _(26), "gtk-help");
	g_signal_connect(GTK_ACTION(action_buffer), "activate", G_CALLBACK(wndMain::s_help_clicked), (wndMain *) this);
	gtk_action_group_add_action_with_accel(action_group, action_buffer, _(19));

	action_buffer = gtk_action_new("quit", _(7), _(27), "gtk-quit");
	g_signal_connect(GTK_ACTION(action_buffer), "activate", G_CALLBACK(wndMain::s_delete_event), (wndMain *) this);
	gtk_action_group_add_action_with_accel(action_group, action_buffer, _(20));

	
	//UI
	ui_manager = gtk_ui_manager_new();
	gtk_ui_manager_add_ui_from_string(ui_manager,
										"<ui><toolbar name=\"ToolBar\"><toolitem name=\"new_file\" action=\"new_file\"/><toolitem name=\"open_file\" action=\"open_file\"/><toolitem name=\"save_file\" action=\"save_file\"/><toolitem name=\"save_file_as\" action=\"save_file_as\"/><toolitem name=\"render\" action=\"render\"/><toolitem name=\"info\" action=\"info\"/><toolitem name=\"quit\" action=\"quit\"/></toolbar><accelerator action=\"new_file\"/><accelerator action=\"open_file\"/><accelerator action=\"save_file\"/><accelerator action=\"save_file_as\"/><accelerator action=\"render\"/><accelerator action=\"info\"/><accelerator action=\"quit\"/></ui>",
										-1, NULL);

	gtk_ui_manager_insert_action_group(ui_manager, action_group, 00);
	menu = gtk_ui_manager_get_widget(ui_manager, "/ToolBar");
	gtk_window_add_accel_group(GTK_WINDOW(window), gtk_ui_manager_get_accel_group(ui_manager));
	gtk_toolbar_set_style(GTK_TOOLBAR(menu), GTK_TOOLBAR_ICONS);

	gtk_widget_show(menu);
	
	gtk_box_pack_start(GTK_BOX(box1), menu, TRUE, TRUE, 0);
	gtk_widget_show(box1);


	//second horizontal box, including a simple textedit (left) and the special "interpreter" (right)
	box2 = gtk_hbox_new(TRUE, 5);
	
	scroll = gtk_scrolled_window_new(NULL, NULL);
	gtk_box_pack_start(GTK_BOX(box2), scroll, TRUE, TRUE, 0);
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

	text_edit = gtk_text_view_new();
	text_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_edit));
	gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(text_edit), GTK_WRAP_WORD);
	gtk_container_add(GTK_CONTAINER(scroll), text_edit);
	
	font_desc = pango_font_description_from_string ("FreeMono bold 9");
    gtk_widget_modify_font (text_edit, font_desc);
    pango_font_description_free (font_desc);

	gtk_widget_show(text_edit);
	gtk_widget_show(scroll);

	interpreter.init(box2, owl_path);
	gtk_widget_show(box2);

	//show the window or no one will see the "masterpiece" ;-)
 	gtk_box_pack_start(GTK_BOX(main_box), box1, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(main_box), box2, TRUE, TRUE, 0);

	gtk_widget_show(main_box);
	gtk_container_add(GTK_CONTAINER(window), main_box);
	gtk_widget_show(window);

	g_log_set_handler(NULL, G_LOG_LEVEL_WARNING, s_warning_handler, (wndMain *) this);

}

//static member functions
gint wndMain::s_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data) {
	gtk_main_quit();
	return FALSE;
}

void wndMain::s_help_clicked(GtkAction *action, gpointer data) {
	wndMain *pThis = (wndMain *) data;
	pThis->help_clicked();
}

void wndMain::s_render_clicked(GtkAction *action, gpointer data) {
	wndMain *pThis = (wndMain *) data;
	pThis->render_clicked();
}

void wndMain::s_load_clicked(GtkAction *action, gpointer data) {
	wndMain *pThis = (wndMain *) data;
	pThis->load_clicked();
}

void wndMain::s_new_clicked(GtkAction *action, gpointer data) {
	wndMain *pThis = (wndMain *) data;
	pThis->new_clicked();
}

void wndMain::s_save_clicked(GtkAction *action, gpointer data) {
	wndMain *pThis = (wndMain *) data;
	pThis->save_file_clicked();
}

void wndMain::s_save_as_clicked(GtkAction *action, gpointer data) {
	wndMain *pThis = (wndMain *) data;
	pThis->save_file_as_clicked();
}

void wndMain::s_warning_handler(const gchar *log_domain, GLogLevelFlags log_level, const gchar *message, gpointer user_data) {
	
	//do nothing
/*	g_print("--------------------------------------------------------------------------------Warning:\n");
	g_print(message);
	g_print("\n--------------------------------------------------------------------------------\n\n");
*/
}

/*
void wndMain::s_store_filename(GtkWidget *widget, gpointer data) {

struct_param *structure = (struct_param *) data;
const gchar *selected_filename;
GString *string;
	
	string = g_string_new("owl editor - ");

	selected_filename = gtk_file_selection_get_filename (GTK_FILE_SELECTION (structure->pWidget));
   
	structure->pThis->filepath = g_filename_to_utf8(selected_filename, -1, NULL, NULL, NULL);
	
	string = g_string_append(string, structure->pThis->filepath);

	gtk_window_set_title(GTK_WINDOW(structure->pThis->window), g_string_free(string, FALSE));

	switch(structure->do_after) {
	case 0:
		structure->pThis->load_file();
		break;
	case 1:
		structure->pThis->save_file();
		break;
	}
}

*/

//methods
void wndMain::render_clicked() {
//	GtkWidget *dialog;
	GtkTextIter start, end;
	gchar *text;

	gtk_text_buffer_get_selection_bounds(GTK_TEXT_BUFFER(text_buffer), &start, &end);
	text = gtk_text_buffer_get_text(GTK_TEXT_BUFFER(text_buffer), &start, &end, FALSE);

	interpreter.parse(text);
}


void wndMain::help_clicked() {
	GtkWidget *dialog;
	
	dialog = gtk_message_dialog_new(GTK_WINDOW(window),
									GTK_DIALOG_DESTROY_WITH_PARENT,
									GTK_MESSAGE_INFO,
									GTK_BUTTONS_OK,
									_(8)
									);
	gtk_dialog_run (GTK_DIALOG (dialog));
	gtk_widget_destroy (dialog);
}

void wndMain::load_clicked() {

	
/*	
	//old
	//show a file selection dialog

	GtkWidget *file_selector;
 
	file_selector = gtk_file_selection_new ("Please select a file for editing.");
   
	gtk_file_selection_complete(GTK_FILE_SELECTION(file_selector), "*.*");

	param.pThis = this;
	param.pWidget = file_selector;
	param.do_after = 0;

	g_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION (file_selector)->ok_button),
                     "clicked",
                     G_CALLBACK (s_store_filename),
                     (gpointer) &param);
   
	g_signal_connect_swapped (GTK_OBJECT (GTK_FILE_SELECTION (file_selector)->ok_button),
                             "clicked",
                             G_CALLBACK (gtk_widget_destroy), 
                             (gpointer) file_selector); 

	g_signal_connect_swapped (GTK_OBJECT (GTK_FILE_SELECTION (file_selector)->cancel_button),
                             "clicked",
                             G_CALLBACK (gtk_widget_destroy),
                             (gpointer) file_selector); 
   
   gtk_widget_show (file_selector);

*/  
	//new file-chooser
	GtkWidget * dialog;
	
	dialog = gtk_file_chooser_dialog_new (	_(9),
											GTK_WINDOW(window),
											GTK_FILE_CHOOSER_ACTION_OPEN,
											GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
											GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
											NULL);
	
	GtkFileFilter *filter_dic = gtk_file_filter_new();
	GtkFileFilter *filter_all = gtk_file_filter_new();

	gtk_file_filter_set_name(filter_dic, _(10));
	gtk_file_filter_add_pattern(filter_dic, "*.dicml");

	gtk_file_filter_set_name(filter_all, _(11));
	gtk_file_filter_add_pattern(filter_all, "*.*");

	gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), filter_dic);
	gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), filter_all);

	if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT) {
	
		filepath = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
		load_file();

	}
	
	gtk_widget_destroy (dialog);

}

void wndMain::new_clicked() {
	//remove text from text_edit and free the filepath-variable
	//TODO: add question "do you want to save..."

	gtk_text_buffer_set_text(text_buffer, "", -1);
	filepath = "";
	gtk_window_set_title(GTK_WINDOW(window), _(0));
}

void wndMain::save_file_clicked() {

	if(!filepath || (filepath == "")) {
		save_file_as_clicked();
	}
	else {
		save_file();
	}

}

void wndMain::save_file_as_clicked() {
	//show a file selection dialog

	GtkWidget * dialog;
	
	dialog = gtk_file_chooser_dialog_new (	_(12),
											GTK_WINDOW(window),
											GTK_FILE_CHOOSER_ACTION_SAVE,
											GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
											GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
											NULL);
	
	GtkFileFilter *filter_dic = gtk_file_filter_new();
	GtkFileFilter *filter_all = gtk_file_filter_new();

	gtk_file_filter_set_name(filter_dic, _(10));
	gtk_file_filter_add_pattern(filter_dic, "*.dicml");

	gtk_file_filter_set_name(filter_all, _(11));
	gtk_file_filter_add_pattern(filter_all, "*.*");

	gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), filter_dic);
	gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), filter_all);

	if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT) {
	
		filepath = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
		save_file();
		
	}
	gtk_widget_destroy(dialog);
}

//helper functions

void wndMain::load_file() {
	gchar * string;
	
	//TODO: error checking
	g_file_get_contents(filepath, &string, NULL, NULL);
	if(g_utf8_validate(string, -1, NULL) == FALSE) {
		string = _(13);
	}

	gtk_text_buffer_set_text(GTK_TEXT_BUFFER(text_buffer), string, -1);
}

void wndMain::save_file() {
	GIOChannel *channel;
	GtkTextIter start, end;
	gchar *text;

	gtk_text_buffer_get_bounds(GTK_TEXT_BUFFER(text_buffer), &start, &end);
	text = gtk_text_buffer_get_text(GTK_TEXT_BUFFER(text_buffer), &start, &end, FALSE);

	channel = g_io_channel_new_file(filepath, "w", NULL);

	g_io_channel_write_chars(channel, text, -1, NULL, NULL);

	g_io_channel_flush(channel, NULL);

	g_io_channel_unref(channel);

	//remove the id-file (as it needs a new one)
	remove(g_strdup_printf("%s.id", filepath));
}
