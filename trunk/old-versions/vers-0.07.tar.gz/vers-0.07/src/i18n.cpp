#include "i18n.h"

void i18n::load_language(gchar* path_to_file) {
	gchar* text;
	gchar* id_string;
	gint id_value;
	gchar* line;

	gunichar line_first_char;
	gchar *found_char;
	glong found_long;


	GIOChannel *file;

	if(array_already_used) {
		g_array_free(strings, TRUE);
	}
	highest_id = -1;
	strings = g_array_new(TRUE, TRUE, sizeof(gchar*));

	file = g_io_channel_new_file(path_to_file, "r", NULL);
	if(file !=0) {
		while( g_io_channel_read_line(file, &line, NULL, NULL, NULL) != G_IO_STATUS_EOF) {

			if(g_utf8_validate(line, -1, NULL)) {
					//decide, wether the line is empty, a comment or contains translation-infos
					line_first_char = g_utf8_get_char(line);
					if( (line_first_char == '\n') || (line_first_char == 13) || (line_first_char == '#')) {
						//do nothing
					}
					else {
						//find out the id-number
						found_char = g_utf8_strchr(line, -1, ':');
						found_long = g_utf8_pointer_to_offset(line, found_char);
						id_string = g_new(gchar, found_long * 6 + 1);
						g_utf8_strncpy(id_string, line, found_long);
						*g_utf8_offset_to_pointer(id_string, found_long) = '\0';
						id_value = g_strtod(id_string, NULL);
						//get the rest and put it into the array
//						text = g_utf8_next_char(found_char, -1);
                                                text = g_utf8_next_char(found_char);
						if(id_value > highest_id) {
							g_array_set_size(strings, id_value+1);
							highest_id = id_value;
						}
						g_strstrip(text);
						g_array_remove_index(strings, id_value);
						g_array_insert_val(strings, id_value, text);
					}
				}
		}
		g_free(line);
	}
	
}


gchar* i18n::gettext_by_id(gint id) {
	gchar *result;

	if(id <=highest_id) {
		result = g_strcompress(g_array_index(strings,gchar*, id));
		g_free(g_array_index(strings, gchar*, id));
		g_array_remove_index(strings, id);
		g_array_insert_val(strings, id, result);
		return result;

	}
	else {
		return "";
	}
}
