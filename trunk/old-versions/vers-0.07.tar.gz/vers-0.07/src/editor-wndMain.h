#include <gtk/gtk.h>
#include <stdio.h>
#include "dicMlRead.h"
#include "i18n.h"

class wndMain {
public:

	struct struct_param {
		wndMain *pThis;
		GtkWidget *pWidget;
		int do_after;
	};

	void init(gchar* path);

	//events (static)
	static gint s_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data);
	static void s_help_clicked(GtkAction *action, gpointer data);
	static void s_render_clicked(GtkAction *action, gpointer data);
	static void s_load_clicked(GtkAction *action, gpointer data);
	static void s_new_clicked(GtkAction *action, gpointer data);
	static void s_save_clicked(GtkAction *action, gpointer data);
	static void s_save_as_clicked(GtkAction *action, gpointer data);
//	static void s_store_filename(GtkWidget *widget, gpointer data);

	static void s_warning_handler(const gchar *log_domain, GLogLevelFlags log_level, const gchar *message, gpointer user_data);
	
private:
	//events (the "real" ones)
	void quit_clicked();
	void help_clicked();
	void render_clicked();
	void load_clicked();
	void new_clicked();
	
	//helper functions
	void load_file();
	void save_file_clicked();
	void save_file_as_clicked();

	void save_file();

	GtkWidget *text_edit;
	GtkTextBuffer *text_buffer;
	GtkWidget *dicml;
	dicmlRead interpreter;
	i18n intl;
	GtkWidget *window;

	gchar* filepath;
	struct_param param;

//The following variable holds the path to the owl-directory
	gchar *owl_path;

};
