#include <gtk/gtk.h>
#include <stdlib.h>

#define MAX_ATT 50

class dicmlRead {
public:
	
	//definitions for the structures to store the contents of the entry
	//see the definitions of dicml 1.0 rc1 (available as pdf-file, but only in German) for more information
/*	struct StructAtt {
		gchar* dom;
		gchar* gram;
		gchar* n;
		gchar* niv;
		gchar* pos;
		gchar* num;
	};
	
	
	struct StructOr {
		gchar* alt1;
		gchar* alt2;
		StructAtt att;
	};

	struct StructLink {
		gchar* text;
		gchar* href;
	};

	struct StructW {
		GArray* text;
		GArray* t_or;
		StructAtt att;
	};

	struct StructS {
		GArray* text;
		GArray* t_or;
		GArray* w;
	};

	struct StructT {
		GArray* text;
		GArray* t_or;
		GArray* w;
	};

	struct StructP {
		StructS s;
		GArray* t;
		StructAtt att;
	};

	struct StructIdiom {
		StructP p;
		GArray* ex;
	};

	struct StructEx {
		GArray* s;
		GArray* t;
		StructAtt att;
	};	

	struct StructIdiomGr {
		GArray* idiom;
	};

	struct StructLemmaGr {
		gchar* num;
		gchar* l;
		gchar* phon;
		gchar* pos;
		gchar* redirect;
	};
	
	struct StructSenseGr {
		GArray* p; //always from type StructP
		GArray* ex; //always from type StructEx
		StructIdiomGr idiomGr;
		StructAtt att;
		gchar* test;
	}; */

	struct StructNode {
		gchar* name;
		gchar* value;
		gchar* att_name[MAX_ATT];
		gchar* att_value[MAX_ATT];
		gint att_count;
	};

	//functions
	void init(GtkWidget * parent_box, gchar *path);
	void parse(gchar *string);
	//////////////////////////////
	static void s_conf_start(GMarkupParseContext *context,
                          const gchar         *element_name,
                          const gchar        **attribute_names,
                          const gchar        **attribute_values,
                          gpointer             user_data,
                          GError             **error);

	//////////////////////////////
	static void s_start_element(GMarkupParseContext *context,
                          const gchar         *element_name,
                          const gchar        **attribute_names,
                          const gchar        **attribute_values,
                          gpointer             user_data,
                          GError             **error);
	static void s_end_element(GMarkupParseContext *context,
                          const gchar         *element_name,
                          gpointer             user_data,
                          GError             **error);
	static void s_text(GMarkupParseContext *context,
                          const gchar         *text,
                          gsize                text_len,  
                          gpointer             user_data,
                          GError             **error);
	static gboolean s_traverse (GNode *node, gpointer data);
private:
	///////////////////////////////
	void conf_start(const gchar         *element_name,
                       const gchar        **attribute_names,
                       const gchar        **attribute_values);
	///////////////////////////////
	
	gboolean traverse (GNode *node);

	void start_element(const gchar         *element_name,
                       const gchar        **attribute_names,
                       const gchar        **attribute_values);
	void text(const gchar         *text,
              gsize                text_len);
	void end_element(const gchar* element_name);
	void init_tags();
	void init_conf();
	void show_lemma();
	void show_sense(GNode* sense_node);
	void show_p(GNode* p_node);
	void show_ex(GNode* ex_node);
	void show_idiom(GNode* idiom_node);
	void show_s(GNode* s_node);
	void show_t(GNode* t_node, gboolean last_t);
	void show_or(GNode* or_node);
	void show_tilde(GNode* tilde_node);
	void show_w(GNode* w_node);
	gint get_element_define(const gchar* element_name);

	GNode* child_node_by_name(gchar* name, GNode* parent, GNode* start_node);
	gchar* att_value_by_name(StructNode* data, gchar* name);

	GtkWidget * widget;
	GtkTextBuffer * text_buffer;
	GtkTextIter start, end;

	GMarkupParser  parser;
	GMarkupParseContext * context;

	GMarkupParser  conf_parser;
	GMarkupParseContext * conf_context;
	
	//kind of "history" or better "hierachy" for the tags
	//GArray* tag_history;

	//holding the concrete content of the entry
	GNode* root_node, *entry;
	GNode* current_parent;

	gchar* owl_path;
};
