#include <gtk/gtk.h>

class i18n {

public:
			void load_language(gchar* path_to_file);
			gchar* gettext_by_id(gint id);
private:
			GArray *strings;
			gboolean array_already_used;
			gint highest_id;
};
