//The following variable holds the path to the owl-directory
gchar *owl_path;
