//(c) 2004 by Thomas Krause

#include "dicMlRead.h"

#define TAG_ENTRY			200
#define TAG_LEMMA_GR	201
#define TAG_SENSE_GR	202
#define TAG_IDIOM_GR	203
#define TAG_NUM				204
#define TAG_L					205
#define TAG_PHON			206
#define TAG_POS				207
#define TAG_REDIRECT	208
#define TAG_IDIOM			210
#define TAG_P					211
#define TAG_EX				212
#define	TAG_S					213
#define TAG_T					214
#define TAG_INFO			215
#define TAG_W					216
#define TAG_OR				217
#define TAG_LINK			218	

void dicmlRead::init(GtkWidget * parent_box, gchar* path) {
GtkWidget *scroll;

	owl_path = path;	

	scroll = gtk_scrolled_window_new(NULL, NULL);
	gtk_box_pack_start(GTK_BOX(parent_box), scroll, TRUE, TRUE, 0);
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);


	widget = gtk_text_view_new();
	text_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(widget));
	
	gtk_text_view_set_editable(GTK_TEXT_VIEW(widget), FALSE);
	gtk_text_view_set_cursor_visible(GTK_TEXT_VIEW(widget), FALSE);
	gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(widget), GTK_WRAP_WORD);

	gtk_widget_show(widget);

	gtk_container_add(GTK_CONTAINER(scroll), widget);
	
	gtk_widget_show(scroll);

	//parser
	parser.start_element = &dicmlRead::s_start_element;
	parser.text = &dicmlRead::s_text;
	parser.end_element = &dicmlRead::s_end_element;

	//tags

	init_tags();

}

void dicmlRead::init_conf() {
//init parser
	conf_parser.start_element = &dicmlRead::s_conf_start;

//read out the xml-file
	gchar * string;
	
	//TODO: error checking
//	g_file_get_contents(filepath, &string, NULL, NULL);
	if(g_utf8_validate(string, -1, NULL) == FALSE) {
		string = "the chosen file contains unvalid characters";
	}
//	conf_context = g_markup_parse_context_new(&conf_parser, (GMarkupParseFlags) 0, (gpointer) this, NULL);

//	g_markup_parse_context_parse(conf_context, string, -1, NULL);

//	g_markup_parse_context_end_parse(conf_context, NULL);
}

void dicmlRead::init_tags() {
	gchar * string;
	gchar **elements;
	gchar **u_elements;
	gchar **cur_elem;
	gchar **u_cur_elem;
	gchar *buffer1;
	
	gchar * name, * font, * weight, * style, * red, * green, * blue, * rise;
	
	GdkColor color;
	PangoStyle style2;

	//TODO: error-checking
	g_file_get_contents(g_strdup_printf("%s/etc/owl/tags.conf",owl_path), &string, NULL, NULL);
//	g_file_get_contents("../ETC/TAGS.CONF", &string, NULL, NULL);

	g_strstrip(string);

	elements = g_strsplit(string, "\n", -1);
	
	cur_elem = elements;

	while(*cur_elem != NULL) {
		buffer1 = *cur_elem;

		g_strstrip(string);
		
		u_elements = g_strsplit(buffer1, ":", -1);

		u_cur_elem = u_elements;
		name = *u_cur_elem;
		u_cur_elem++;
		font = *u_cur_elem;
		u_cur_elem++;
		weight = *u_cur_elem;
		u_cur_elem++;
		style = *u_cur_elem;
		u_cur_elem++;
		red = *u_cur_elem;
		u_cur_elem++;
		green = *u_cur_elem;
		u_cur_elem++;
		blue = *u_cur_elem;
		u_cur_elem++;
		rise = *u_cur_elem;

		color.red = (guint16) atoi(red);
		color.green = (guint16) atoi(green);
		color.blue = (guint16) atoi(blue);


		if(g_utf8_collate(style, "PANGO_STYLE_NORMAL") == 0) {
			style2 = PANGO_STYLE_NORMAL;
		}
		else if(g_utf8_collate(style, "PANGO_STYLE_ITALIC") == 0) {
			style2 = PANGO_STYLE_ITALIC;
		}
		else if(g_utf8_collate(style, "PANGO_STYLE_OBLIQE") == 0) {
			style2 = PANGO_STYLE_OBLIQUE;
		}
		else {
			style2 = PANGO_STYLE_NORMAL;
		}
		
		gtk_text_buffer_create_tag(text_buffer, name, "font", font, "weight", atoi(weight), "style", style2, "foreground-gdk", &color, "rise", atoi(rise), NULL);	


		cur_elem++;
	}
	g_strfreev(u_elements);
	g_strfreev(elements);
}

void dicmlRead::s_conf_start(GMarkupParseContext *context,
                          const gchar         *element_name,
                          const gchar        **attribute_names,
                          const gchar        **attribute_values,
                          gpointer             user_data,
                          GError             **error) {
	dicmlRead * pThis = (dicmlRead *) user_data;

	pThis->conf_start(element_name, attribute_names, attribute_values);

}

void dicmlRead::s_start_element(GMarkupParseContext *context,
                          const gchar         *element_name,
                          const gchar        **attribute_names,
                          const gchar        **attribute_values,
                          gpointer             user_data,
                          GError             **error) {
	
	dicmlRead * pThis = (dicmlRead *) user_data;

	pThis->start_element(element_name, attribute_names, attribute_values);
}

void dicmlRead::s_end_element(GMarkupParseContext *context,
                          const gchar         *element_name,
                          gpointer             user_data,
                          GError             **error) {
	dicmlRead * pThis = (dicmlRead *) user_data;
	pThis->end_element(element_name);
}

void dicmlRead::s_text(GMarkupParseContext *context,
                          const gchar         *text,
                          gsize                text_len,  
                          gpointer             user_data,
                          GError             **error) {
	dicmlRead * pThis = (dicmlRead *) user_data;

	pThis->text(text, text_len);
}


gboolean dicmlRead::s_traverse (GNode *node, gpointer data) {
	dicmlRead * pThis = (dicmlRead *) data;
	return	pThis->traverse(node);
}

void dicmlRead::conf_start(const gchar *element_name, const gchar  **attribute_names, const gchar **attribute_values) {

}

gboolean dicmlRead::traverse(GNode* node) {
	g_free(node->data);

	return TRUE;
}

void dicmlRead::start_element(const gchar *element_name, const gchar  **attribute_names, const gchar **attribute_values) {
	
	//set name and attributes of the node
	StructNode *data = g_new(StructNode, 1);
	data->name = g_strdup(element_name);
	gint x=0;
		if(x<MAX_ATT) {	
			data->att_name[x] = g_strdup(*attribute_names);
			if(*attribute_values != NULL) {
				data->att_value[x] = g_strdup(*attribute_values);
			}
		}
		x++;
		attribute_names++;
		attribute_values++;
//	}
	data->att_count = x;
	//append node
	GNode *node = g_node_append_data(current_parent, data);
	//set this node as the new parent-node
	current_parent = node;
}

void dicmlRead::end_element(const gchar* element_name) {
	//reset the parent-node
	GNode *node = current_parent;
	current_parent = node->parent;
}

void dicmlRead::text(const gchar *text, gsize text_len) {
	StructNode *data = g_new(StructNode, 1);
	data->name = g_strdup("#text");
	data->value = g_strdup(text);
	//append node
	GNode *node = g_node_append_data(current_parent, data);
}

void dicmlRead::parse(gchar *string) {
	
	gchar *buffer;
	GNode *sense_gr;


	//erase old text from buffer

	gtk_text_buffer_set_text(text_buffer, "", -1);
		
	
	if(g_utf8_validate(string, -1, NULL) == FALSE) {
		gtk_text_buffer_set_text(text_buffer, "{Error: The string contains unvalid characters!}", -1);
	}

	//init parser and variables
	buffer = g_strdup("root_node");
	root_node = g_node_new(buffer);
	current_parent = root_node;
//	tag_history = g_array_new(TRUE, TRUE, sizeof(gint));

	context = g_markup_parse_context_new(&parser, (GMarkupParseFlags) 0, (gpointer) this, NULL);

	g_markup_parse_context_parse(context, string, -1, NULL);

	g_markup_parse_context_end_parse(context, NULL);

	gtk_text_buffer_get_bounds(GTK_TEXT_BUFFER(text_buffer), &start, &end);	

	//find "entry"
	entry = child_node_by_name("entry", root_node, NULL);
	if(entry != NULL) {
		//show everything
		show_lemma();
		
		sense_gr = child_node_by_name("sense.gr", entry, NULL);
		while(sense_gr != NULL) {
			show_sense(sense_gr);
			sense_gr = child_node_by_name("sense.gr", entry, sense_gr);
		}	
	}

	//clean up TODO:do a really [clean] clean-up
	g_node_traverse (root_node, G_IN_ORDER, G_TRAVERSE_ALL, -1, dicmlRead::s_traverse, (gpointer*) this);
	g_node_destroy(root_node);
}

void dicmlRead::show_lemma() {
	GNode* lemma_gr, *child, *text;
	StructNode *data;
	gchar* att;

	//find first "lemma.gr"
	lemma_gr = child_node_by_name("lemma.gr", entry, NULL);
	if(lemma_gr != NULL) {
		//NUM
		child = child_node_by_name("num", lemma_gr, NULL);
		if(child != NULL) {
			//get the text of "num"
			text = child_node_by_name("#text", child, NULL);
			if(text != NULL) {
				data = (StructNode*) text->data;
				gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, data->value, -1, "lemma.gr-num", NULL);
			}
		}
		//L
		child = child_node_by_name("l", lemma_gr, NULL);
		if(child != NULL) {
			//get the text of "l"
			text = child_node_by_name("#text", child, NULL);
			if(text != NULL) {
				data = (StructNode*) text->data;
				gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, data->value, -1, "lemma.gr-l", NULL);
				gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, " ", -1, "lemma.gr-l", NULL);
			}
		}
		//POS
		child = child_node_by_name("pos", lemma_gr, NULL);
		if(child != NULL) {
			//get the att. "pos" of "pos"
			att = att_value_by_name((StructNode*) child->data, "pos");
			if(att != NULL) {
				gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, att, -1, "lemma.gr-pos", NULL);
				gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, " ", -1, "lemma.gr-pos", NULL);
			}
		}
		//PHON
		child = child_node_by_name("phon", lemma_gr, NULL);
		if(child != NULL) {
			//get the text of "phon"
			text = child_node_by_name("#text", child, NULL);
			if(text != NULL) {
				data = (StructNode*) text->data;
				gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, "[", -1, "lemma.gr-phon", NULL);
				gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, data->value, -1, "lemma.gr-phon", NULL);
				gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, "]", -1, "lemma.gr-l", NULL);
			}
		}
	}
	gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, "\n\n", -1, "lemma.gr-phon", NULL);
}

void dicmlRead::show_sense(GNode* sense_node) {
	gchar *num, *dom, *gram, *n, *niv;
	GNode *p, *ex, *idiom_gr;

	//attributes
	num = att_value_by_name((StructNode*) sense_node->data, "num");
	if(num != NULL) {
		gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, num, -1, "sense.gr-num", NULL);
	}
	gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, " ", -1, "sense.gr-num", NULL);
	dom = att_value_by_name((StructNode*) sense_node->data, "dom");
	if(dom != NULL) {
		gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, dom, -1, "sense.gr-dom", NULL);
		gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, " ", -1, "sense.gr-dom", NULL);
	}
	//TODO:gram, n, niv
	
	//all P
	p = child_node_by_name("p", sense_node, NULL);
	while(p != NULL) {
		show_p(p);
		p = child_node_by_name("p", sense_node, p);
	}
	//all EX
	ex = child_node_by_name("ex", sense_node, NULL);
	while(ex != NULL) {
		show_ex(ex);
		ex = child_node_by_name("ex", sense_node, ex);
	}
	//all IDIOM.GR
	idiom_gr = child_node_by_name("idiom.gr", sense_node, NULL);
	while(idiom_gr != NULL) {
		show_idiom(idiom_gr);
		idiom_gr = child_node_by_name("idiom.gr", sense_node, idiom_gr);
	}
	gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, "\n", -1, "sense.gr-num", NULL);

}

void dicmlRead::show_p(GNode* p_node) {
	gchar *dom, *gram, *n, *niv, *pos;
	GNode *s, *t, *t_buffer;
	
	//attributes
	dom = att_value_by_name((StructNode*) p_node->data, "dom");
	if(dom != NULL) {
		gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, dom, -1, "sense.gr-dom", NULL);
		gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, " ", -1, "sense.gr-dom", NULL);
	}
	//TODO:gram, n, niv, pos

	//all S and T
	s = child_node_by_name("s", p_node, NULL);
	t = child_node_by_name("t", p_node, NULL);
	while( (s != NULL) || (t != NULL) ) {
		if(s != NULL) {
			show_s(s);
			s = child_node_by_name("s", p_node, s);
		}
		if(t != NULL) {
			t_buffer = child_node_by_name("t", p_node, t);
			if(t_buffer) {
				show_t(t, FALSE);
			}
			else {
				show_t(t, TRUE);
			}
			t = t_buffer;
		}
	}
	gtk_text_buffer_insert_with_tags_by_name(GTK_TEXT_BUFFER(text_buffer), &end, "\n", -1, "sense.gr-p", NULL);
}

void dicmlRead::show_ex(GNode* ex_node) {

}

void dicmlRead::show_idiom(GNode* idiom_node) {


}

void dicmlRead::show_s(GNode* s_node) {
	GNode *child;
	StructNode * data;
	gint x=0;
	//TODO: attributes

	//go through all child nodes and decide what to do
	child = g_node_nth_child(s_node, x);
	if(child != NULL) {
		do {
			data = (StructNode*) child->data;
			if(g_utf8_collate(data->name, "#text") == 0) {
				gtk_text_buffer_insert_with_tags_by_name(text_buffer, &end, data->value, -1, "sense.gr-s", NULL);
				gtk_text_buffer_insert_with_tags_by_name(text_buffer, &end, " ", -1, "sense.gr-s", NULL);
			}
			else if (g_utf8_collate(data->name, "or") == 0) {
				show_or(child);
			}
			else if (g_utf8_collate(data->name, "w") == 0) {
				show_w(child);
			}
			else if (g_utf8_collate(data->name, "tilde") == 0) {
				show_tilde(child);
			}
			x++;
			child = g_node_nth_child(s_node, x);
		} while (child != NULL);
	}
}

void dicmlRead::show_t(GNode* t_node, gboolean last_t) {

	GNode *child;
	StructNode * data;
	gint x=0;
	GtkTextIter iter;
	//TODO: attributes

	//go through all child nodes and decide what to do
	child = g_node_nth_child(t_node, x);
	if(child != NULL) {
		do {
			data = (StructNode*) child->data;
			if(g_utf8_collate(data->name, "#text") == 0) {
				gtk_text_buffer_insert_with_tags_by_name(text_buffer, &end, data->value, -1, "sense.gr-t", NULL);
				gtk_text_buffer_insert_with_tags_by_name(text_buffer, &end, " ", -1, "sense.gr-t", NULL);
			}
			else if (g_utf8_collate(data->name, "or") == 0) {
				show_or(child);
			}
			else if (g_utf8_collate(data->name, "w") == 0) {
				show_w(child);
			}
			else if (g_utf8_collate(data->name, "tilde") == 0) {
				show_tilde(child);
			}
			x++;
			child = g_node_nth_child(t_node, x);
		} while (child != NULL);

		//;
		if(!last_t) {
			//delete last space-character and insert "; ";
			gtk_text_buffer_get_iter_at_offset(text_buffer, &iter, gtk_text_iter_get_offset(&end)-1);
			gtk_text_buffer_delete(text_buffer, &iter, &end);
			gtk_text_buffer_insert_with_tags_by_name(text_buffer, &end, "; ", -1, "sense.gr-t", NULL);
		}
	}
}

void dicmlRead::show_or(GNode* or_node) {

}

void dicmlRead::show_w(GNode* w_node) {
	//TODO: attributes
	GNode* text;
	StructNode* data;
	StructNode* w_data;
	gchar* n;

	w_data = (StructNode*) w_node->data;
	//n
	n = att_value_by_name(w_data, "n");
	if(n != NULL) {
		gtk_text_buffer_insert_with_tags_by_name(text_buffer, &end, "(", -1, "sense.gr-n", NULL);
		gtk_text_buffer_insert_with_tags_by_name(text_buffer, &end, n, -1, "sense.gr-n", NULL);
		gtk_text_buffer_insert_with_tags_by_name(text_buffer, &end, ") ", -1, "sense.gr-n", NULL);
	}
	//

	text = child_node_by_name("#text", w_node, NULL);
	if(text != NULL) {
		data = (StructNode*) text->data;
		gtk_text_buffer_insert_with_tags_by_name(text_buffer, &end, data->value, -1, "sense.gr-w", NULL);
		gtk_text_buffer_insert_with_tags_by_name(text_buffer, &end, " ", -1, "sense.gr-w", NULL);
	}
}

void dicmlRead::show_tilde(GNode* tilde_node) {
	GNode* text;
	StructNode* data;

	text = child_node_by_name("#text", tilde_node, NULL);
	if(text != NULL) {
		data = (StructNode*) text->data;
		//TODO: decide wether to show the text or not by the user preferences
		gtk_text_buffer_insert_with_tags_by_name(text_buffer, &end, "~", -1, "sense.gr-tilde", NULL);
		gtk_text_buffer_insert_with_tags_by_name(text_buffer, &end, " ", -1, "sense.gr-tilde", NULL);
	}
}

//////////////////////////////////////////////////////////////////////////////////////
GNode* dicmlRead::child_node_by_name(gchar* name, GNode* parent, GNode* start_node) {
	GNode* result_node = NULL;
	StructNode* node_data;

	if(start_node == NULL) {
		start_node = g_node_first_child(parent); 
	}
	else {
		start_node = g_node_next_sibling(start_node);
	}

	if(start_node != NULL) {
		node_data = (StructNode*) start_node->data;
		result_node = start_node;
		while( (result_node != NULL) && (g_utf8_collate(node_data->name, name) != 0) ) {
			result_node = g_node_next_sibling(result_node);
			if(result_node != NULL) {node_data = (StructNode*) result_node->data; }
		}
	}
	return result_node;
}

gchar* dicmlRead::att_value_by_name(StructNode* data, gchar* name) {
	gchar* result = NULL;
	for(gint x=0;x<data->att_count;x++) {
		if(data->att_name[x] != NULL) {
			if(g_utf8_collate(data->att_name[x], name) == 0) {
				result = g_strdup(data->att_value[x]);
			}
		}
	}
return result;
}

gint dicmlRead::get_element_define(const gchar* element_name) {
	gchar* en = g_ascii_strdown(element_name, -1);
	gint rv = 0;
	if(g_utf8_collate(en, "entry") == 0) {
		rv = TAG_ENTRY;
	}
	else if(g_utf8_collate(en, "lemma.gr") == 0) {
		rv = TAG_LEMMA_GR;
	}
	else if(g_utf8_collate(en, "sense.gr") == 0) {
		rv = TAG_SENSE_GR;
	}
	else if(g_utf8_collate(en, "idiom.gr") == 0) {
		rv = TAG_IDIOM_GR;
	}
	else if(g_utf8_collate(en, "num") == 0) {
		rv = TAG_NUM;
	}
	else if(g_utf8_collate(en, "l") == 0) {
		rv = TAG_L;
	}
	else if(g_utf8_collate(en, "phon") == 0) {
		rv = TAG_PHON;
	}
	else if(g_utf8_collate(en, "pos") == 0) {
		rv = TAG_POS;
	}
	else if(g_utf8_collate(en, "redirect") == 0) {
		rv = TAG_REDIRECT;
	}
	else if(g_utf8_collate(en, "idiom") == 0) {
		rv = TAG_IDIOM;
	}
	else if(g_utf8_collate(en, "p") == 0) {
		rv = TAG_P;
	}
	else if(g_utf8_collate(en, "ex") == 0) {
		rv = TAG_EX;
	}
	else if(g_utf8_collate(en, "s") == 0) {
		rv = TAG_S;
	}
	else if(g_utf8_collate(en, "t") == 0) {
		rv = TAG_T;
	}
	else if(g_utf8_collate(en, "info") == 0) {
		rv = TAG_INFO;
	}
	else if(g_utf8_collate(en, "w") == 0) {
		rv = TAG_W;
	}
	else if(g_utf8_collate(en, "or") == 0) {
		rv = TAG_OR;
	}
	else if(g_utf8_collate(en, "link") == 0) {
		rv = TAG_LINK;
	}

	g_free(en);
return rv;
}